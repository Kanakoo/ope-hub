#! /bin/bash
./client 8085
./client 8085
./client 8085
./client 8085
./client 8085

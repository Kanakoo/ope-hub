//#ifndef AES_H
//#define AES_H
//#include <stdio.h>
//#include <string>
//#include <iostream>
//#include <fstream>
//#include <sstream>

//#include <cryptopp/aes.h>
//#include <cryptopp/filters.h>
//#include <cryptopp/modes.h>
//using namespace std;
//class AES
//{
//public:
//    void initKV();
//    string encrypt(string plainText);
//    void writeCipher(string output);
//    string decrypt(string cipherTextHex);
//    string readCipher();
//private:
//    CryptoPP::byte key[ CryptoPP::AES::DEFAULT_KEYLENGTH ];
//    CryptoPP::byte iv[ CryptoPP::AES::BLOCKSIZE];
//};
//#endif

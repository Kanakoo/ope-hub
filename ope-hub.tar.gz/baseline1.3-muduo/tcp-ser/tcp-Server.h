#ifndef TCPSERVER_H
#define TCPSERVER_H
#include "../common/trans/msg.pb.h"
#include "../common/proto_msg.h"
#include "../common/concurrentqueue.h"
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <math.h>
#include <mutex>
#include <time.h>
#include <queue>
#include <atomic>
#include <shared_mutex>
#include <algorithm>
#include "../common/threadpool.h"
#include "../common/util.h"
//#include <brynet/net/EventLoop.hpp>
//#include <brynet/net/TcpService.hpp>
//#include <brynet/net/wrapper/ServiceBuilder.hpp>

#include <muduo/net/TcpServer.h>
#include <muduo/base/AsyncLogging.h>
#include <muduo/base/Logging.h>
#include <muduo/base/Thread.h>
#include <muduo/net/EventLoop.h>
#include <muduo/net/InetAddress.h>

#include <junction/Core.h>
#include <turf/Heap.h>
#include <junction/extra/MapAdapter.h>
#include <junction/ConcurrentMap_Grampa.h>
#include <junction/ConcurrentMap_Grampa.h>
using namespace muduo;
using namespace muduo::net;

//add lqq
//variables
#define NUM_ENCODE 8
#define EXE_TX 1
#define NUM_REC 3
#define NUM_QRY 0
extern std::atomic<bool> is_reb;
extern std::atomic<bool> is_enc;
extern std::mutex mtx_recque;
//extern std::mutex mtx_write;
extern std::mutex mtx_txqueue;
extern std::mutex mtx_list;
extern std::mutex mtx_qry;
//extern std::mutex mtx_reb;
//pthread_rwlock_t rwlock=PTHREAD_RWLOCK_INITIALIZER;
//extern std::shared_timed_mutex rwlock;
extern std::atomic<int> version;
extern std::atomic<int> abort_num;
extern std::atomic<int> conflict_num;
extern std::atomic<int> reb_num;
extern Node* root/*=new Node()*/;
//HZC
//extern std::map<int,std::vector<myPkg>> rst_list;
extern std::map<int,myPkg> rst_list;
extern std::map<int,std::vector<send_item>> qry_list;
//extern std::queue<enc_req> enc_queue;
//extern std::queue<Tx> tx_buffer;
extern moodycamel::ConcurrentQueue<enc_req> enc_queue;
extern moodycamel::ConcurrentQueue<Tx> tx_buffer;
extern std::atomic<int> block_id;
//HZC
//extern std::vector<TcpConnection::Ptr> clients;
//extern TcpService::Ptr service;
extern std::map<int,TcpConnectionPtr> clients;
//extern std::map<int,TcpConnPtr> clients;
//extern EventBase eventbase;
//HZC
void addClientID(int index, const TcpConnectionPtr &con);
//void removeClientID(const TcpConnection::Ptr& con);
//HZC timestamp
extern timeval mystart;
extern timeval myend;
extern timeval tpsstart;
extern timeval tpsend;
extern cool::ThreadPool pool;
//typedef junction::ConcurrentMap_Grampa<turf::u64, std::vector<myPkg>> ConcurrentMap1;
typedef junction::ConcurrentMap_Grampa<turf::u64, myPkg*> ConcurrentMap1;
typedef junction::ConcurrentMap_Grampa<turf::u64, void*> ConcurrentMap2;
extern ConcurrentMap1 rstMap;
extern ConcurrentMap2 countMap;

void Inorder(Node* node,vector<string>& tmp_list,map<string,int>& tmp_map);
void Inorder(vector<string>& tmp_list,map<string,int>& tmp_map);
void Inorder1(Node* node,int& num);
void Print(int& num);
void traverse(Node* root,int64_t k1, int64_t k2, vector<string>& res);
void searchRange(int64_t k1, int64_t k2, vector<string>& res);
void range_query(int newSd,string k1, string k2, vector<string>& res);
void destory();
void destory(Node*& p);
void Update(vector<string>& data,map<string,int>& tmp_map);
int Encode(int newSd);
void execute_tx(Tx& tx,Block& tx_block);
int Encode1(string current,map<string,int>& tmp_map);
int Encode2();
//HZC
//void addClientID(const TcpConnection::Ptr& session);
//void removeClientID(const TcpConnection::Ptr& session);
//int Encode_no_interact();
//extern map<string,int64_t> text;
#endif // TCPSERVER_H

#include "util.h"
#include <sys/socket.h>
#include <unistd.h>
//int send_msg(int Sd,send_item& item)
//{
//    usleep(1);
//    char msg[item.get_serialize_size()];
//    memset(msg, 0, sizeof(msg));
//    item.serialize(msg);
//    int n=send(Sd, (char*)&msg, item.get_serialize_size(), 0);
//    //cout<<"send:"<<item.get_serialize_size()<<", "<<n<<endl;
//    return n;
//}
//int rec_msg(int Sd,send_item& item)
//{
//    //usleep(1);

//    char msg[4096];
//    memset(msg, 0, sizeof(msg));
//    int n=recv(Sd, (char*)&msg, 4096, 0);
//    item.deserialize(msg);
//    //cout<<"rec:"<<item.get_serialize_size()<<", "<<n<<endl;
//    return n;
//}
//int send_json(int Sd,Json::Value& value)
//{
//    usleep(1);
//    int size=value.toStyledString().length()+1;
//    char msg[size];
//    memset(msg, 0, sizeof(msg));
//    memcpy(msg,value.toStyledString().c_str(),size);
//    int n=send(Sd, (char*)&msg, size, 0);
//    return n;
//}
//int rec_json(int Sd,Json::Value& value)
//{
//    char msg[4096];
//    memset(msg, 0, sizeof(msg));
//    int n=recv(Sd, (char*)&msg, 4096, 0);
//    char* jsonstr=msg;
//    Json::Reader  reader;
//    if (!reader.parse(jsonstr, value)){
//        cout << "error" << endl;
//        return 0;
//    }
//    return n;
//}
//int send_block(int Sd,Block& block)
//{
//    usleep(1);
//    char msg[BLOCK_SIZE1];
//    memset(msg, 0, sizeof(msg));
//    block.serialize(msg);
//    int n=send(Sd, (char*)&msg, block.get_serialize_size(), 0);
//    //cout<<"block size:"<<block.get_serialize_size()<<","<<n<<endl;
//    return n;
//}
//int rec_block(int Sd,Block& block)
//{
//    char msg[BLOCK_SIZE1];
//    memset(msg, 0, sizeof(msg));
//    int n=recv(Sd, (char*)&msg, BLOCK_SIZE1, 0);
//    //cout<<"rrrrrrrrcv:"<<n<<endl;
//    block.deserialize(msg);
//    return n;
//}

//send_item to_Item(Json::Value& jsonObj)
//{
//    send_item item;
//    item.enc_id=(int)jsonObj["enc_id"].asInt();
//    return item;
//}
const char* serialize_block(Block& block)
{
    Json::Value json_blk;
    json_blk["block_id"]=block.block_id;
    json_blk["tx_n"]=block.n;
    for(int i=0;i<block.n;i++)
    {
        Tx tx=block.get(i);
        Json::Value json_tx;
        json_tx["tx_type"]=tx.tx_type;
        json_tx["cipher"]=tx.cipher;
        json_tx["y"]=to_string(tx.y);
        json_tx["path"]=tx.path;
        json_tx["v_bef"]=tx.v_bef;
        json_blk["tx_batch"].append(json_tx);
    }
    return json_blk.toStyledString().c_str();
}
Block deserialize_block(const char* buf)
{
    Json::Value json_blk;
    Json::Reader reader;
    Block block;
    if (!reader.parse(buf, json_blk)){
        cout << "error parse block!" << endl;
        return block;
    }
    else
    {
        block.block_id=json_blk["block_id"].asInt();
        block.n=json_blk["tx_n"].asInt();
        cout<<block.n<<endl;
        for(int i=0;i<block.n;i++)
        {
            Tx tx;
            tx.tx_type=json_blk["tx_batch"][i]["tx_type"].asInt();
            tx.cipher=json_blk["tx_batch"][i]["cipher"].asString();
            tx.y=std::atoi(json_blk["tx_batch"][i]["y"].asString().c_str());
            tx.path=json_blk["tx_batch"][i]["path"].asString();
            tx.v_bef=json_blk["tx_batch"][i]["v_bef"].asInt();
            block.tx_batch.push_back(tx);
        }
    }
    return block;
}

#ifndef UTIL_H
#define UTIL_H
#include <iostream>
#include <string.h>
#include <string>
#include <vector>
#include <mutex>
#include <sys/types.h>
#include "json/json.h"

//HZC
#define TXN 8192
#define M 1073741824
#define ERR -9999
#define BLOCK_SIZE1 50000
#define TX_PER_BLOCK 100
using namespace std;
enum MSG_TYPE{
    REQ_ENC=0,
    REQ_CMP,
    CMP_RST,
    SORT_UDZ,
    RESORT_TX,
    TX,
    REB_TX,
    REQ_RQ,
    REQ_RQCMP,
    RQCMPRST,
    RQRST
};
struct Node;
typedef struct Node
{
   string cipher="";
   int64_t code=ERR;
    Node* left;
    Node* right;
    Node* parent;
//    bool lock=0;
    Node(string x,int64_t y)
    {
        left=nullptr;
        right=nullptr;
        parent=nullptr;
        cipher=x;
        code=y;
    }
    Node()
    {
        left=nullptr;
        right=nullptr;
        parent=nullptr;
        code=ERR;

    }

}Node;
typedef struct send_item
{
    int enc_id=-1;
    int msg_id=-1;
    int msg_type=-1;
    string tmp="";
    string cipher="";
    int64_t y=ERR;
    int rst=ERR;//compare two ciphertxts:tmp and cipher

    //write
    string path="";
    int v_bef=0;
    //query
    string lrange="";
    string rrange="";
    vector<string> rs;
    int rs_n=0;
    send_item()
    {

    }
    void push_rs(string cipher)
    {
        rs.push_back(cipher);
        rs_n++;
    }
//    send_item& operator=(const send_item& item)
//    {
//        // 避免自赋值
//        this->enc_id=item.enc_id;
//        this->msg_id=item.msg_id;
//        this->msg_type=item.msg_type;
//        this->tmp=item.tmp;
//        this->cipher=item.cipher;
//        this->path=item.path;
//        this->y=item.y;
//        this->rst=item.rst;
//        this->v_bef=item.v_bef;
//        return *this;
//    }
    bool is_written()
    {
        return (msg_id!=-1 && msg_type>-1 && tmp.length()>0 && cipher.length()>0 && path.length()>0 && rst!=ERR);
    }
    bool is_written_cmp()
    {
        return (msg_id!=-1 && msg_type>-1 && tmp.length()>0 && cipher.length()>0);
    }
    void serialize(char* buffer)
    {
       int pos=0;
       memcpy(buffer+pos,&enc_id,sizeof(int));
       pos+=sizeof(enc_id);

       memcpy(buffer+pos,&msg_id,sizeof(int));
       pos+=sizeof(msg_id);

       memcpy(buffer+pos,&msg_type,sizeof(msg_type));
       pos+=sizeof(msg_type);

       int tmp_len=tmp.length();
       memcpy(buffer+pos,&tmp_len,sizeof(int));
       pos+=sizeof(int);
       memcpy(buffer+pos,tmp.c_str(),tmp_len);
       pos+=tmp_len;

       int cip_len=cipher.length();
       memcpy(buffer+pos,&cip_len,sizeof(int));
       pos+=sizeof(int);
       memcpy(buffer+pos,cipher.c_str(),cip_len);
       pos+=cip_len;

       memcpy(buffer+pos,&y,sizeof(int64_t));
       pos+=sizeof(y);

       memcpy(buffer+pos,&rst,sizeof(int));
       pos+=sizeof(rst);

       int pa_len=path.length();
       memcpy(buffer+pos,&pa_len,sizeof(int));
       pos+=sizeof(int);
       memcpy(buffer+pos,path.c_str(),pa_len);
       pos+=pa_len;

       memcpy(buffer+pos,&v_bef,sizeof(int));
       pos+=sizeof(v_bef);

       int lrg_len=lrange.length();
       memcpy(buffer+pos,&lrg_len,sizeof(int));
       pos+=sizeof(int);
       memcpy(buffer+pos,lrange.c_str(),lrg_len);
       pos+=lrg_len;

       int rrg_len=rrange.length();
       memcpy(buffer+pos,&rrg_len,sizeof(int));
       pos+=sizeof(int);
       memcpy(buffer+pos,rrange.c_str(),rrg_len);
       pos+=rrg_len;

       memcpy(buffer+pos,&rs_n,sizeof(int));
       pos+=sizeof(rs_n);

       for(int i=0;i<rs_n;i++)
       {
           string result=rs.at(i);
           int rs_len=result.length();
           memcpy(buffer+pos,&rs_len,sizeof(int));
           pos+=sizeof(int);
           memcpy(buffer+pos,result.c_str(),rs_len);
           pos+=rs_len;
       }

    }

    void deserialize(const char* buffer)
    {
       //cout<<"deserialize"<<endl;
       int pos=0;
       int *current=0;

       current = (int*)buffer;
       enc_id=*current;
       pos+=sizeof(enc_id);

       current = (int*)(buffer+pos);
       msg_id=*current;
       pos+=sizeof(msg_id);

       current = (int*)(buffer+pos);
       msg_type=*current;
       pos+=sizeof(msg_type);

       current=(int*)(buffer+pos);
       int tmp_len=*current;
       pos+=sizeof(int);
       string tmpstr((char*)(buffer+pos),tmp_len);
       tmp=tmpstr;
       pos+=tmp_len;

       current=(int*)(buffer+pos);
       int cip_len=*current;
       pos+=sizeof(int);
       string cipstr((char*)(buffer+pos),cip_len);
       cipher=cipstr;
       pos+=cip_len;

       int64_t* curr;
       curr = (int64_t*)(buffer+pos);
       y=*curr;
       pos+=sizeof(y);

       current = (int*)(buffer+pos);
       rst=*current;
       pos+=sizeof(rst);

       current=(int*)(buffer+pos);
       int pa_len=*current;
       pos+=sizeof(int);
       string pastr((char*)(buffer+pos),pa_len);
       path=pastr;
       pos+=pa_len;

       current = (int*)(buffer+pos);
       v_bef=*current;
       pos+=sizeof(v_bef);

       current=(int*)(buffer+pos);
       int lrg_len=*current;
       pos+=sizeof(int);
       string lrgstr((char*)(buffer+pos),lrg_len);
       lrange=lrgstr;
       pos+=lrg_len;

       current=(int*)(buffer+pos);
       int rrg_len=*current;
       pos+=sizeof(int);
       string rrgstr((char*)(buffer+pos),rrg_len);
       rrange=rrgstr;
       pos+=rrg_len;

       current = (int*)(buffer+pos);
       rs_n=*current;
       pos+=sizeof(rs_n);

       for(int i=0;i<rs_n;i++)
       {
           current=(int*)(buffer+pos);
           int rs_len=*current;
           pos+=sizeof(int);
           string result((char*)(buffer+pos),rs_len);
           rs.push_back(result);
           pos+=rs_len;
       }

    }
    int get_serialize_size()
    {
       int pos=0;
       pos+=sizeof(enc_id);
       pos+=sizeof(msg_id);
       pos+=sizeof(msg_type);
       pos+=sizeof(int);
       pos+=tmp.length();
       pos+=sizeof(int);
       pos+=cipher.length();
       pos+=sizeof(y);
       pos+=sizeof(rst);
       pos+=sizeof(int);
       pos+=path.length();
       pos+=sizeof(v_bef);
       pos+=sizeof(int);
       pos+=lrange.length();
       pos+=sizeof(int);
       pos+=rrange.length();
       pos+=sizeof(int);
       for(int i=0;i<rs_n;i++)
       {
           pos+=sizeof(int);
           string result=rs.at(1);
           pos+=result.length();
       }
       return pos;
    }
    void Print()
    {
        cout<<"-----------------print item----------------"<<endl;
        cout<<"enc_id:"<<enc_id<<endl;
        cout<<"msg_id:"<<msg_id<<endl;
        cout<<"msg_type:"<<msg_type<<endl;
        cout<<"tmp:"<<tmp<<endl;
        cout<<"cipher:"<<cipher<<endl;
        cout<<"path:"<<path<<endl;
        cout<<"-----------------print end----------------"<<endl;
    }
    void to_Json(Json::Value& jsonObj)
    {
        jsonObj["enc_id"] = enc_id;
        jsonObj["msg_id"] = msg_id;
        jsonObj["msg_type"] = msg_type;
        jsonObj["tmp"] = tmp;
        jsonObj["cipher"] = cipher;
//        jsonObj["y"] = y;
        jsonObj["rst"] = rst;
        jsonObj["path"] = path;
        jsonObj["lrange"] = lrange;
        jsonObj["rrange"] = rrange;
        jsonObj["rs_n"] = rs_n;
        for(int i=0;i<rs_n;i++)
        {
            jsonObj["rs"].append(rs[i]);
        }
    }

}send_item;
typedef struct Tx
{
    int tx_type=-1;
    string cipher="";
    int64_t y=ERR;
    string path="";
    int v_bef=0;
    Tx()
    {

    }
    Tx& operator=(const Tx& tx)
    {
        // 避免自赋值
        this->tx_type=tx.tx_type;
        this->cipher=tx.cipher;
        this->y=tx.y;
        this->path=tx.path;
        this->v_bef=tx.v_bef;
        return *this;
    }
    void Print()
    {
        cout<<"-----------------print tx----------------"<<endl;
        cout<<"tx_type:"<<tx_type<<endl;
        cout<<"cipher:"<<cipher<<endl;
        cout<<"y:"<<y<<endl;
        cout<<"path:"<<path<<endl;
        cout<<"v_bef:"<<v_bef<<endl;
        cout<<"-----------------print end----------------"<<endl;
    }
}Tx;
typedef struct Block
{
    vector<Tx> tx_batch;
    int n=0;
    int block_id=0;
    void push(Tx tx)
    {
        tx_batch.push_back(tx);
        n++;
    }
    Tx get(int i)
    {
        return tx_batch.at(i);
    }
    void clear()
    {
        tx_batch.clear();
        block_id=0;
        n=0;
    }
//    Block& operator=(const Block& block)
//    {
//        // 避免自赋值
//        this->n=block.n;
//        this->block_id=block.block_id;
//        this->tx_batch.clear();
//        for(int i=0;i<n;i++)
//        {

//            this->tx_batch.push_back(block.tx_batch.at(i));
//        }
//        return *this;
//    }
    void serialize(char* buffer)
    {
       int pos=0;
       memcpy(buffer+pos,&n,sizeof(int));
       pos+=sizeof(n);
       memcpy(buffer+pos,&block_id,sizeof(int));
       pos+=sizeof(block_id);
       for(int i=0;i<n;i++)
       {
           Tx tx=tx_batch[i];
           memcpy(buffer+pos,&tx.tx_type,sizeof(int));
           pos+=sizeof(tx.tx_type);

           int cip_len=tx.cipher.length();
           memcpy(buffer+pos,&cip_len,sizeof(int));
           pos+=sizeof(int);
           memcpy(buffer+pos,tx.cipher.c_str(),cip_len);
           pos+=cip_len;

           memcpy(buffer+pos,&tx.y,sizeof(int64_t));
           pos+=sizeof(tx.y);

           int pa_len=tx.path.length();
           memcpy(buffer+pos,&pa_len,sizeof(int));
           pos+=sizeof(int);
           memcpy(buffer+pos,tx.path.c_str(),pa_len);
           pos+=pa_len;

           memcpy(buffer+pos,&tx.v_bef,sizeof(int));
           pos+=sizeof(tx.v_bef);
       }
    }

    void deserialize(char* buffer)
    {
       //cout<<"deserialize"<<endl;
        int pos=0;
        int *current=0;

        current = (int*)(buffer+pos);
        n=*current;
        pos+=sizeof(n);
        current = (int*)(buffer+pos);
        block_id=*current;
        pos+=sizeof(block_id);
        for(int i=0;i<n;i++)
        {
            Tx tx;
            current = (int*)(buffer+pos);
            tx.tx_type=*current;

            pos+=sizeof(tx.tx_type);

            current=(int*)(buffer+pos);
            int cip_len=*current;
            pos+=sizeof(int);
            string cipstr((char*)(buffer+pos),cip_len);
            tx.cipher=cipstr;
            pos+=cip_len;

            int64_t* curr;
            curr = (int64_t*)(buffer+pos);
            tx.y=*curr;
            pos+=sizeof(tx.y);

            current=(int*)(buffer+pos);
            int pa_len=*current;
            pos+=sizeof(int);
            string pastr((char*)(buffer+pos),pa_len);
            tx.path=pastr;
            pos+=pa_len;

            current = (int*)(buffer+pos);
            tx.v_bef=*current;
            pos+=sizeof(tx.v_bef);
            tx_batch.push_back(tx);
        }
    }
    int get_serialize_size()
    {
       int pos=0;
       pos+=sizeof(n);
       pos+=sizeof(n);
       for(int i=0;i<n;i++)
       {
           Tx tx=tx_batch[i];
           pos+=sizeof(tx.tx_type);
           pos+=sizeof(int);
           pos+=tx.cipher.length();
           pos+=sizeof(tx.y);
           pos+=sizeof(int);
           pos+=tx.path.length();
           pos+=sizeof(tx.v_bef);

       }
       return pos;
    }
    void Print()
    {
        cout<<"--------print block-------"<<n<<endl;
        cout<<"block id is "<<block_id<<endl;
        for(int i=0;i<n;i++)
        {
            cout<<"tx: type="<<tx_batch[i].tx_type<<", code="<<tx_batch[i].y<<", cip="<<tx_batch[i].cipher<<", path="<<tx_batch[i].path<<endl;
        }
        cout<<"--------end-------"<<endl;
    }
}Block;
typedef struct enc_req
{
    string cipher="";
    int id=0;
}enc_req;
struct thread_data{
   int thread_id;
   string message;
   int left;
   int right;
};
//int send_msg(int Sd,send_item& item);
//int rec_msg(int Sd,send_item& item);
//int send_block(int Sd,Block& block);
//int rec_block(int Sd,Block& block);
//int send_json(int Sd,Json::Value& value);
//int rec_json(int Sd,Json::Value& value);
//send_item to_Item(Json::Value& jsonObj);
const char* serialize_block(Block& block);
Block deserialize_block(const char* buf);
#endif // UTIL_H

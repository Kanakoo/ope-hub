#include <iostream>
#include "tcp-Server.h"


//tree functions
std::atomic<bool> is_reb{0};
std::atomic<bool> is_enc{0};
std::mutex mtx_recque;
//std::mutex mtx_write;
std::mutex mtx_txqueue;
std::mutex mtx_list;
std::mutex mtx_qry;
//std::shared_timed_mutex rwlock;
//std::mutex mtx_reb;
//pthread_rwlock_t rwlock=PTHREAD_RWLOCK_INITIALIZER;
//std::shared_timed_mutex rwlock;
std::atomic<int> version{0};
std::atomic<int> abort_num{0};
std::atomic<int> conflict_num{0};
std::atomic<int> reb_num{0};
std::atomic<int> counttps{0};
Node* root=new Node();
//HZC
//std::map<int,std::vector<myPkg>> rst_list;
std::map<int,myPkg> rst_list;
std::map<int,std::vector<send_item>> qry_list;
//std::queue<enc_req> enc_queue;
//std::queue<Tx> tx_buffer;
moodycamel::ConcurrentQueue<Tx> tx_buffer;
moodycamel::ConcurrentQueue<enc_req> enc_queue;
std::atomic<int> block_id{0};
//HZC
//std::vector<TcpConnection::Ptr> clients;
//TcpService::Ptr service;
//std::map<int,TcpConnPtr> clients;
//std::map<int,TcpConnection::Ptr> clients;
//map<intptr_t, TcpConnPtr> users;
//HZC timsstamp
std::map<int,TcpConnectionPtr> clients;
timeval mystart;
timeval myend;
timeval qpsstart;
timeval qpsend;
ConcurrentMap1 rstMap;
ConcurrentMap2 countMap;
//EventBase eventbase;
//cool::ThreadPool pool(24);
void addClientID(int index,const TcpConnectionPtr &con)
{
    //    clients.push_back(session);
    cout<<"client num:"<<index<<endl;
    clients[index]=con;
}

//void removeClientID(const TcpConnection::Ptr &con)
//{
//    //    for (auto it = clients.begin(); it != clients.end(); ++it)
//    //    {
//    //        if (*it == session)
//    //        {
//    //            clients.erase(it);
//    //            break;
//    //        }
//    //    }
//}
//Block tx_block;

//map<string,int64_t> text;

//HZC
//static void addClientID(const TcpConnection::Ptr& session)
//{
//    clients.push_back(session);
//}

//static void removeClientID(const TcpConnection::Ptr& session)
//{
//    for (auto it = clients.begin(); it != clients.end(); ++it)
//    {
//        if (*it == session)
//        {
//            clients.erase(it);
//            break;
//        }
//    }
//}
void Inorder(Node* node,vector<string>& tmp_list,map<string,int>& tmp_map)
{
    if(node==nullptr)
        return;
    Inorder(node->left,tmp_list,tmp_map);
    if(node->code!=-1 && node->code!=M && node->code!=ERR)
    {
        tmp_list.push_back(node->cipher);
        tmp_map[node->cipher]=node->code;
    }
    Inorder(node->right,tmp_list,tmp_map);
}
void Inorder(vector<string>& tmp_list,map<string,int>& tmp_map)
{
    tmp_map[root->cipher]=root->code;
    tmp_map[root->right->cipher]=root->right->code;
    Inorder(root,tmp_list,tmp_map);
    //    sort(tmp_list.begin(),tmp_servicelist.end(),sortFunLst);
}
void Inorder1(Node* node,int& num)
{
    if(node==nullptr)
        return;
    Inorder1(node->left,num);
    //    cout<<"entry"<<num<<":  x="<<node->cipher<<",y="<<node->code<<endl;
    num++;
    Inorder1(node->right,num);
}
void Print(int& num)
{
    num=0;
    cout<<"====begin print===="<<endl;
    Inorder1(root,num);
    cout<<"====end print===="<<endl;
    num-=2;
    cout<<"total num: "<<num<<endl;
}

void destory(Node*& p)
{
    if(p!=nullptr)
    {
        if(p->left!=nullptr)
            destory(p->left);
        if(p->right!=nullptr)
            destory(p->right);
        delete p;
        p=nullptr;
    }
}
void destory()
{
    destory(root);
}
void traverse(Node* root,int64_t k1, int64_t k2, vector<string>& res)
{//采用前序遍历
    if(root == NULL)
        return;
    if(k1 <= root->code && k2 >= root->code)//满足条件的就存入
        res.push_back(root->cipher);
    traverse(root->left,k1,k2,res);
    traverse(root->right,k1,k2,res);
}
void searchRange(int64_t k1, int64_t k2, vector<string>& res)
{
    // write your code here
    if(root == NULL)
        return;
    traverse(root,k1,k2,res);
    return;
}

//encode functions

void execute_tx(Tx& tx,Block& tx_block)
{
    //cout<<"*********execute:"<<tx.cipher<<endl;
    if(tx.tx_type==REB_TX)
    {
        while(is_enc)
        {

        }
        is_reb=1;
        version++;
        vector<string> tmp_list;
        map<string,int> tmp_map;
        Inorder(tmp_list,tmp_map);
        destory();
        root=new Node("cipher-1",-1);
        Node* node=new Node("cipher"+to_string(TXN),M);
        root->right=node;
        node->parent=root;
        Update(tmp_list,tmp_map);
        //cout<<"*********execute update:"<<tx.cipher<<endl;
        is_reb=0;
        //Print();
    }
    else if(tx.tx_type==TX)
    {
        int v_aft=version;
        if(v_aft!=tx.v_bef)
        {
            abort_num++;
            reb_num++;
            //cout<<"abort:"<<tx.cipher<<" version changed,"<<tx.v_bef<<","<<version<<endl;
            return;
        }
        else
        {
            Node* tmp=root;
            string path=tx.path;
            for(int i=0;i<path.length()-1;i++)
            {
                if(tmp!=nullptr)
                {
                    if(path[i]=='0')
                        tmp=tmp->left;
                    else
                        tmp=tmp->right;
                }
                else
                {
                    //cerr<<"reb conflict:"<<tx.cipher<<endl;
                    abort_num++;
                    reb_num++;
                    return;
                }
            }
            //            while(tmp->lock==1)
            //            {

            //            }
            //            tmp->lock=1;
            Node* node=new Node(tx.cipher,tx.y);
            char c=path[path.length()-1];
            if(c=='0')
            {
                if(tmp->left!=nullptr)
                {
                    //cout<<"abort "<<tx.cipher<<" node exist"<<endl;
                    conflict_num++;
                    abort_num++;
                    //                    tmp->lock=0;
                    return;
                }
                else
                {
                    node->parent=tmp;
                    tmp->left=node;
                }

            }
            else
            {
                if(tmp->right!=nullptr)
                {
                    //cout<<"abort "<<tx.cipher<<" node exist"<<endl;
                    conflict_num++;
                    abort_num++;
                    //                    tmp->lock=0;
                    return;
                }
                else
                {
                    node->parent=tmp;
                    tmp->right=node;
                }
            }
            //            tmp->lock=0;
            //cout<<"*********execute success:"<<tx.cipher<<endl;
            //Print();
        }
    }
    else
    {
        cerr<<"wrong msg type:"<<tx.tx_type<<endl;
        return;
    }
    tx_block.push(tx);
}

int Encode1(string current,map<string,int>& tmp_map)
{
    Node* tmp=root;
    Node* parent=nullptr;
    int y=0,y1=0,y2=0;
    Node* node=new Node(current,ERR);
    if(tmp==nullptr)
    {
        return ERR;
    }
    else
    {
        while(tmp!=nullptr)
        {
            parent=tmp;
            if(tmp_map[current] == tmp_map[parent->cipher])
            {
                return tmp->code;
            }
            else if(tmp_map[current] < tmp_map[parent->cipher])
            {
                tmp=tmp->left;
            }
            else
            {
                tmp=tmp->right;
            }
        }
        if(parent!=nullptr)
        {
            node->parent=parent;
            if(tmp_map[current] < tmp_map[parent->cipher])
            {
                if(parent->left!=nullptr)
                {
                    return ERR;
                }
                parent->left=node;
                y2=parent->code;
                Node* p=parent;
                while(p!=nullptr && p->code>=y2)
                {
                    p=p->parent;
                }
                if(p!=nullptr)
                    y1=p->code;

            }
            else
            {
                if(parent->right!=nullptr)
                {
                    return ERR;
                }
                parent->right=node;
                y1=parent->code;
                Node* p=parent;
                while(p!=nullptr && p->code<=y1)
                {
                    p=p->parent;
                }
                if(p!=nullptr)
                    y2=p->code;
            }
            y=y1+ceil((float)(((float)y2-(float)y1)/2));
            node->code=y;
            return -2;
        }
        else
        {
            return ERR;
        }
    }
}
void Update(vector<string>& data,map<string,int>& tmp_map)
{
    int i=data.size();//插入x之前有i个数需要重新编码
    if(i<=0)
    {
        cout<<"!!!!!!!!tree is nullptr!"<<endl;
        return;
    }
    int idx=floor((float)i/2)+1;//idx是中值的下标
    string current=data[idx-1];
    //cout<<"clear update "<<data[idx-1]<<endl;
    Encode1(current,tmp_map);//-1是因为相对于数组中的位置
    vector<string> left_lst;
    vector<string> right_lst;
    left_lst.assign(data.begin(), data.begin()+idx-1);
    right_lst.assign(data.begin()+idx, data.end());
    if(i>1) Update(left_lst,tmp_map);
    if(i>2) Update(right_lst,tmp_map);
}
int Encode2()
{
    enc_req enc;
    bool found=enc_queue.try_dequeue(enc);
    if(found)
    {
        if(root==nullptr)
            return ERR;
        else if(root->right==nullptr)
        {
            return ERR;
        }
        else
        {
            int64_t y1=0,y2=0,y=0;
            int v_bef=version;
            string path="1";
            string cipherx=enc.cipher;
            int enc_id=enc.id;
            int msg_id=0;
            Node* tmp=root->right;
            Node* parent=nullptr;
            while(1)
            {
                if(tmp==nullptr)
                    break;
                parent=tmp;
                myPkg pkg;
                std::string str;
                pkg.set_msgtype(REQ_CMP);
                pkg.set_encid(enc_id);
                pkg.set_msgid(msg_id);
                pkg.set_tmp(tmp->cipher);
                pkg.set_cipher(cipherx);
                pkg.set_path(path);
                pkg.SerializeToString(&str);
//                rstMap.assign(enc_id,&pkg);
//                cout<<"------------send----------"<<endl;
//                cout<<"send:msgtyp="<<pkg.msgtype()<<endl;
//                cout<<"send:msgid="<<pkg.msgid()<<endl;
//                cout<<"send:encid="<<pkg.encid()<<endl;
//                cout<<"send:encid="<<pkg.tmp()<<endl;
//                cout<<"send:encid="<<pkg.cipher()<<endl;
//                cout<<"------------end----------"<<endl;
                //HZC
//                TcpConnPtr con = clients[enc_id%clients.size()];
//                eventbase.safeCall([con,str,enc_id]() { con->sendMsg(str); });
//                char * strc = new char[strlen(str.c_str())+1];
//                strcpy(strc, str.c_str());
//                cout<<str.size()<<endl;
//                cout<<str<<endl;
//                 clients[enc_id%clients.size()]->send(str.c_str(), str.size());
                //HZC
//                if(enc_id==1000){
//                    timeval temp;
//                    gettimeofday(&temp,NULL);
//                    cout<<temp.tv_sec<<" "<<temp.tv_usec<<endl;
//                    cout<<msg_id<<endl;
//                }
                //HZC
                clients[enc_id%clients.size()]->send(str);
                while(1)
                {
                    mtx_list.lock();
//                    rstMap.get(enc_id).size()
                    //HZC
//                    if(rstMap.get(enc_id).size()>msg_id)
//                    myPkg* rec_rst1 =rstMap.get(enc_id);
                    if(rst_list[enc_id].msgid()==msg_id)
                    {
                        myPkg rec_rst1=rst_list[enc_id];
                        mtx_list.unlock();
//                        cout<<"------------rec----------"<<endl;
//                        cout<<"rec:msgtyp="<<rec_rst1->msgtype()<<endl;
//                        cout<<"rec:msgid="<<rec_rst1->msgid()<<endl;
//                        cout<<"rec:encid="<<rec_rst1->encid()<<endl;
//                        cout<<"rec:encid="<<rec_rst1->tmp()<<endl;
//                        cout<<"rec:encid="<<rec_rst1->cipher()<<endl;
//                        cout<<"------------rec----------"<<endl;
                        if(rec_rst1.path()!="")
                        {
                            msg_id++;
                            path=rec_rst1.path();
                            break;
                        }
                    }
                    else
                    {
                        mtx_list.unlock();
                    }
                }
                if(path=="0")
                    return tmp->code;
                char next1=path[path.length()-1];
                if(next1=='0')
                    tmp=tmp->left;
                else
                    tmp=tmp->right;


            }
            if(parent!=nullptr)
            {
                if(path[path.length()-1]=='0')
                {
                    y2=parent->code;
                    Node* p=parent;
                    while(p!=nullptr && p->code>=y2)
                    {
                        p=p->parent;
                    }
                    if(p!=nullptr)
                        y1=p->code;

                }
                else
                {
                    y1=parent->code;
                    Node* p=parent;
                    while(p!=nullptr && p->code<=y1)
                    {
                        p=p->parent;
                    }
                    if(p!=nullptr)
                        y2=p->code;
                }
                Tx tx;
                if(y2-y1==1)
                {
                    //                    tx_item.msg_type=REB_TX;
                    tx.tx_type=REB_TX;
                    enc_queue.enqueue(enc);
//                    mtx_list.lock();
//                    rst_list[enc.id].clear();
//                    mtx_list.unlock();
//                    rstMap.get(enc.id).clear();
                    //cout<<"-------update "<<cipherx<<endl;
                }
                else
                {
                    //tx_item.msg_type=TX;
                    tx.tx_type=TX;
                    float a=(float)y1;
                    float b=(float)y2;
                    y=y1+ceil((float)(b-a)/2);
                    //                     int a=y1+1,b=y2-1;
                    //                     y=(rand() % (b-a+1))+ a;
                }

                //                tx_item.cipher=cipherx;
                //                tx_item.path=path;
                //                tx_item.y=y;
                //                tx_item.v_bef=v_bef;
                //test tx
                tx.v_bef=v_bef;
                tx.y=y;
                tx.cipher=cipherx;
                tx.path=path;
                //mtx_txqueue.lock();
                //tx_buffer.push(tx);
                tx_buffer.enqueue(tx);
                //mtx_txqueue.unlock();
                //test end

                //                send_msg(newSd,tx_item);
                return 0;

            }
            else
            {
                cout<<"!!!!err parent is nullptr"<<endl;
                return ERR;
            }

        }
    }

}
//int Encode_no_interact()
//{
//    while(is_reb==1)
//    {

//    }
//    enc_req enc;
//    bool found=enc_queue.try_dequeue(enc);
//    if(found)
//    {

//        if(root==nullptr)
//            return ERR;
//        else if(root->right==nullptr)
//        {
//            return ERR;
//        }
//        else
//        {
//            int64_t y1=0,y2=0,y=0;
//            int v_bef=version;
//            string path="1";
//            string cipherx=enc.cipher;
//            Node* tmp=root->right;
//            Node* parent=nullptr;
//            while(1)
//            {
//                if(tmp==nullptr)
//                    break;
//                parent=tmp;

//                int cmp=text[tmp->cipher]-text[cipherx];
//                if(cmp>0)
//                {
//                    path+="0";
//                    tmp=tmp->left;
//                }
//                else if(cmp<0)
//                {
//                    path+="1";
//                    tmp=tmp->right;
//                }
//                else
//                {
//                   return tmp->code;
//                }


//            }
//            if(parent!=nullptr)
//            {
//                if(path[path.length()-1]=='0')
//                {
//                    y2=parent->code;
//                    Node* p=parent;
//                    while(p!=nullptr && p->code>=y2)
//                    {
//                        p=p->parent;
//                    }
//                    if(p!=nullptr)
//                        y1=p->code;

//                }
//                else
//                {
//                    y1=parent->code;
//                    Node* p=parent;
//                    while(p!=nullptr && p->code<=y1)
//                    {
//                        p=p->parent;
//                    }
//                    if(p!=nullptr)
//                        y2=p->code;
//                }

//                Tx tx;
//                if(y2-y1==1)
//                {
////                    tx_item.msg_type=REB_TX;
//                    tx.tx_type=REB_TX;
//                    enc_queue.enqueue(enc);
//                    //cout<<"-------update "<<cipherx<<endl;
//                }
//                else
//                {
//                    //tx_item.msg_type=TX;
//                    tx.tx_type=TX;
//                    float a=(float)y1;
//                    float b=(float)y2;
//                    y=y1+ceil((float)(b-a)/2);
////                     int a=y1+1,b=y2-1;
////                     y=(rand() % (b-a+1))+ a;
//                }

//                //test tx
//                tx.v_bef=v_bef;
//                tx.y=y;
//                tx.cipher=cipherx;
//                tx.path=path;
//                //mtx_txqueue.lock();
//                //tx_buffer.push(tx);
//                tx_buffer.enqueue(tx);
//                //mtx_txqueue.unlock();
//                //test end

////                send_msg(newSd,tx_item);
//                return 0;

//            }
//            else
//            {
//                cout<<"!!!!err parent is nullptr"<<endl;
//                return ERR;
//            }

//        }
//    }

//}

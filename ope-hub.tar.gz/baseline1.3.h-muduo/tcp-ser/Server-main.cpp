#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <math.h>
#include "tcp-Server.h"

std::atomic_llong TotalRecvSize = ATOMIC_VAR_INIT(0);
std::atomic_llong total_client_num = ATOMIC_VAR_INIT(0);
std::atomic_llong total_packet_num = ATOMIC_VAR_INIT(0);

using namespace std;
using namespace muduo;
using namespace muduo::net;

void* write_tree(void *threadarg)
{
    //-------connect
    //    char *serverIp1 = "127.0.0.1"; int port1 =8081/* atoi(argv[2])*/;
    //    struct hostent* host1 = gethostbyname(serverIp1);
    //    sockaddr_in sendSockAddr1;
    //    bzero((char*)&sendSockAddr1, sizeof(sendSockAddr1));
    //    sendSockAddr1.sin_family = AF_INET;
    //    sendSockAddr1.sin_addr.s_addr =inet_addr(inet_ntoa(*(struct in_addr*)*host1->h_addr_list));
    //    sendSockAddr1.sin_port = htons(port1);
    //    int clientSd1 = socket(AF_INET, SOCK_STREAM, 0);
    //    //try to connect...
    //    int status = connect(clientSd1,(sockaddr*) &sendSockAddr1, sizeof(sendSockAddr1));
    //    if(status < 0)
    //    {
    //        cout<<"Error connecting to socket!"<<endl;
    //    }
    //    cout << "Connected to the Node!" << endl;
    //    -------connect end
    //    while (1) {
    //        //usleep(200000);
    //        mtx_txqueue.lock();
    //        if(tx_buffer.size()>=TX_PER_BLOCK)
    //        {
    //            Block tx_block;
    //            tx_block.block_id=block_id;
    //            for(int i=0;i<TX_PER_BLOCK;i++)
    //            {
    //                Tx tx=tx_buffer.front();
    //                tx_buffer.pop();
    //                execute_tx(tx,tx_block);
    //            }
    //            mtx_txqueue.unlock();
    //            send_block(clientSd1,tx_block);
    //            tx_block.Print();
    //            int num=0;
    //            Print(num);
    //            block_id++;
    //        }
    //        else
    //        {
    //            mtx_txqueue.unlock();
    //        }
    //    }
    //    while(1)
    //    {
    //        int count = 0;
    //        mtx_txqueue.lock();
    //        Block tmp_block;
    //        while(!tx_buffer.empty())
    //        {
    //            Tx tx=tx_buffer.front();
    //            q.enqueue(tx);
    //            tx_buffer.pop();
    //            tmp_block.push(tx);
    //            if(count>=TX_PER_BLOCK){
    //                break;
    //            }
    //        }
    //        mtx_txqueue.unlock();
    //        Block new_block;
    //        new_block.block_id=block_id;
    //        for(int i=0;i<tmp_block.n;i++){
    //            Tx tx1 = tmp_block.get(i);
    //            execute_tx(tx1,new_block);
    //            gettimeofday(&end,NULL);
    //            float time_use=(end.tv_sec-start.tv_sec)*1000000+(end.tv_usec-start.tv_usec);//微秒
    //            printf("time_use is %.10f\n",time_use);
    //        }

    //        if(new_block.n>0){
    //            //new_block.Print();

    //            //send_block(clientSd1,new_block);
    //        }
    //        block_id++;

    //    }
    int nn=0;
    timeval end;
    while(1)
    {

        Block tmp_block;
        int count = 0;
        while(1)
        {
            Tx tx;
            bool found=tx_buffer.try_dequeue(tx);
            if(found)
            {
                tmp_block.push(tx);
                nn++;
                count++;
                if(count>=TX_PER_BLOCK){
                    break;
                }
            }else{
                break;
            }
        }
        Block new_block;
        new_block.block_id=block_id;
        for(int i=0;i<tmp_block.n;i++){
            Tx tx1 = tmp_block.get(i);
            execute_tx(tx1,new_block);
            gettimeofday(&end,NULL);
            //HZC
            int time_use=end.tv_sec;
            int time_use1=end.tv_usec;
            //                        if(nn>=995){
            ////                            int num=0;
            ////                            Print(num);
            ////                            abort_num=N-num;
            ////                            conflict_num=abort_num-reb_num;
            ////                            cout<<"abort num: "<<abort_num<<", conflict_num: "<<conflict_num<<", reb_num: "<<reb_num<<", update time: "<<version<<endl;
            //                            printf("time_use is %d %d, tx num is %d\n",time_use,time_use1,nn);
            //                        }
            gettimeofday(&myend,NULL);
        }
        if(new_block.n>0){
//            usleep(10000);
            //send_block(clientSd1,new_block);
        }
        block_id++;

    }

}

void* write_treePool(int index)
{
    //-------connect
    //    char *serverIp1 = "127.0.0.1"; int port1 =8081/* atoi(argv[2])*/;
    //    struct hostent* host1 = gethostbyname(serverIp1);
    //    sockaddr_in sendSockAddr1;
    //    bzero((char*)&sendSockAddr1, sizeof(sendSockAddr1));
    //    sendSockAddr1.sin_family = AF_INET;
    //    sendSockAddr1.sin_addr.s_addr =inet_addr(inet_ntoa(*(struct in_addr*)*host1->h_addr_list));
    //    sendSockAddr1.sin_port = htons(port1);
    //    int clientSd1 = socket(AF_INET, SOCK_STREAM, 0);
    //    //try to connect...
    //    int status = connect(clientSd1,(sockaddr*) &sendSockAddr1, sizeof(sendSockAddr1));
    //    if(status < 0)
    //    {
    //        cout<<"Error connecting to socket!"<<endl;
    //    }
    //    cout << "Connected to the Node!" << endl;
    //    -------connect end
    //    while (1) {
    //        //usleep(200000);
    //        mtx_txqueue.lock();
    //        if(tx_buffer.size()>=TX_PER_BLOCK)
    //        {
    //            Block tx_block;
    //            tx_block.block_id=block_id;
    //            for(int i=0;i<TX_PER_BLOCK;i++)
    //            {
    //                Tx tx=tx_buffer.front();
    //                tx_buffer.pop();
    //                execute_tx(tx,tx_block);
    //            }
    //            mtx_txqueue.unlock();
    //            send_block(clientSd1,tx_block);
    //            tx_block.Print();
    //            int num=0;
    //            Print(num);
    //            block_id++;
    //        }
    //        else
    //        {
    //            mtx_txqueue.unlock();
    //        }
    //    }
    //    while(1)
    //    {
    //        int count = 0;
    //        mtx_txqueue.lock();
    //        Block tmp_block;
    //        while(!tx_buffer.empty())
    //        {
    //            Tx tx=tx_buffer.front();
    //            q.enqueue(tx);
    //            tx_buffer.pop();
    //            tmp_block.push(tx);
    //            if(count>=TX_PER_BLOCK){
    //                break;
    //            }
    //        }
    //        mtx_txqueue.unlock();
    //        Block new_block;
    //        new_block.block_id=block_id;
    //        for(int i=0;i<tmp_block.n;i++){
    //            Tx tx1 = tmp_block.get(i);
    //            execute_tx(tx1,new_block);
    //            gettimeofday(&end,NULL);
    //            float time_use=(end.tv_sec-start.tv_sec)*1000000+(end.tv_usec-start.tv_usec);//微秒
    //            printf("time_use is %.10f\n",time_use);
    //        }

    //        if(new_block.n>0){
    //            //new_block.Print();

    //            //send_block(clientSd1,new_block);
    //        }
    //        block_id++;

    //    }
    int nn=0;
    timeval end;
    while(1)
    {
        Block tmp_block;
        int count = 0;
        while(1)
        {
            Tx tx;
            bool found=tx_buffer.try_dequeue(tx);
            if(found)
            {
                tmp_block.push(tx);
                nn++;
                count++;
                if(count>=TX_PER_BLOCK){
                    break;
                }
            }else{
                break;
            }
        }
        Block new_block;
        new_block.block_id=block_id;
        for(int i=0;i<tmp_block.n;i++){
            Tx tx1 = tmp_block.get(i);
            execute_tx(tx1,new_block);
            gettimeofday(&end,NULL);
            //HZC
            int time_use=end.tv_sec;
            int time_use1=end.tv_usec;
            //                        if(nn>=995){
            ////                            int num=0;
            ////                            Print(num);
            ////                            abort_num=N-num;
            ////                            conflict_num=abort_num-reb_num;
            ////                            cout<<"abort num: "<<abort_num<<", conflict_num: "<<conflict_num<<", reb_num: "<<reb_num<<", update time: "<<version<<endl;
            //                            printf("time_use is %d %d, tx num is %d\n",time_use,time_use1,nn);
            //                        }
            gettimeofday(&myend,NULL);
        }
        if(new_block.n>0){
            //send_block(clientSd1,new_block);
        }
        block_id++;

    }

}
//void* do_encode(void *threadarg)
void* do_encode(void *threadarg)
{
    sleep(3);
    //HZC
    timeval start;
    gettimeofday(&mystart,NULL);
    gettimeofday(&start,NULL);
    //    cout<<"start time:"<<start.tv_sec<<","<<start.tv_usec<<endl;
    struct thread_data *my_data;
    my_data = (struct thread_data *) threadarg;
    //    cout << "Do Encode Thread ID : " << my_data->thread_id<<endl;
    while(1)
    {
        while(is_reb)
        {

        }
        is_enc=1;
        Encode2();
        is_enc=0;
    }
}

void* do_encodePool(int index)
{
    //HZC
    timeval start;
    gettimeofday(&mystart,NULL);
    gettimeofday(&start,NULL);
    cout<<"start time:"<<start.tv_sec<<","<<start.tv_usec<<endl;
    //    cout << "Do Encode Thread ID : " << my_data->thread_id<<endl;
    while(1)
    {
        while(is_reb)
        {

        }
        is_enc=1;
        Encode2();
        is_enc=0;
    }
}

void* print_tps(void *threadarg){
    while(1){
        sleep(10);
        int num=0;
        Print(num);
        abort_num=TXN-num;
        conflict_num=abort_num-reb_num;
        cout<<"abort num: "<<abort_num<<", conflict_num: "<<conflict_num<<", reb_num: "<<reb_num<<", update time: "<<version<<endl;
        float time_use=(myend.tv_sec-mystart.tv_sec)*1000000+(myend.tv_usec-mystart.tv_usec);//微秒
        float time_useqps=(qpsend.tv_sec-qpsstart.tv_sec)*1000000+(qpsend.tv_usec-qpsstart.tv_usec);//微秒
        int temp=counttps;
        printf("time_use is %f microseconds, tx num is %d, tps is about %f\n",time_use,num,num*1000000.0/time_use);
        printf("time_useqps is %f microseconds, tx num is %d, tps is about %f\n",time_useqps,temp,temp*1000000.0/time_useqps);
    }
}

void* print_tpsPool(int index){
    while(1){
        sleep(3);
        int num=0;
        Print(num);
        abort_num=TXN-num;
        conflict_num=abort_num-reb_num;
        cout<<"abort num: "<<abort_num<<", conflict_num: "<<conflict_num<<", reb_num: "<<reb_num<<", update time: "<<version<<endl;
        float time_use=(myend.tv_sec-mystart.tv_sec)*1000000+(myend.tv_usec-mystart.tv_usec);//微秒
        printf("time_use is %f microseconds, tx num is %d, tps is about %f\n",time_use,num,(num+1)*1000000.0/time_use);
    }
}

//void* do_rec(const string& input)
//{
//    myPkg pkg;
//    pkg.ParseFromString(input);
//    if(pkg.msgtype()==CMP_RST)
//    {
//        int enc_id=pkg.encid();
//        mtx_list.lock();
//        rst_list[enc_id]=pkg;
//        //cout<<"push "<<enc_id<<" "<<rec_item.cipher<<endl;
//        mtx_list.unlock();
//    }
//    //            else if(rec_item.msg_type==RQCMPRST)
//    //            {
//    //                int enc_id=rec_item.enc_id;
//    //                //int msg_id=rec_item->msg_id;
//    //                mtx_qry.lock();
//    //                qry_list[enc_id].push_back(rec_item);
//    //                mtx_qry.unlock();
//    //            }
//    //            else if(rec_item.msg_type==REB_TX || rec_item.msg_type==TX)
//    //            {
//    //                nn++;
//    //                Tx tx;
//    //                tx.tx_type=rec_item.msg_type;
//    //                tx.v_bef=rec_item.v_bef;
//    //                tx.y=rec_item.y;
//    //                tx.cipher=rec_item.cipher;
//    //                tx.path=rec_item.path;
//    //                mtx_txqueue.lock();
//    //                tx_buffer.push(tx);
//    ////                cout<<"ppppppppppppush tx:"<<tx_buffer.size()<<endl;
//    ////                gettimeofday(&end,NULL);
//    ////                float time_use=(end.tv_sec-start.tv_sec)*1000000+(end.tv_usec-start.tv_usec);//微秒
//    ////                printf("time_use is %.10f\n",time_use);
//    ////                cout<<"tx num "<<nn<<endl;
//    //                mtx_txqueue.unlock();
//    //            }
//    else
//    {
//        cerr<<"wrong message type when rec: "<<pkg.msgtype()<<endl;
//    }
//}

////void onConnection(const TcpConnectionPtr &conn)
////{
////    total_client_num++;
////    addClientID(total_client_num-1,conn);
////    gettimeofday(&qpsstart,NULL);
////    myPkg sen_pkg;
////    sen_pkg.set_encid(1);
////    sen_pkg.set_msgid(1);
////    sen_pkg.set_msgtype(CMP_RST);
////    sen_pkg.set_tmp("hhhhhhh");
////    sen_pkg.set_rst(123);
////    sen_pkg.set_cipher("");
////    sen_pkg.set_path("010101010");
////    std::string str;
////    sen_pkg.SerializeToString(&str);
////    conn->send(str);
////    //    LOG_INFO << "EchoServer - " << conn->peerAddress().toIpPort() << " -> "
////    //             << conn->localAddress().toIpPort() << " is "
////    //             << (conn->connected() ? "UP" : "DOWN");
////}

//void onMessage(const TcpConnectionPtr &conn,
//               Buffer *buf,
//               Timestamp time)
//{
//    //    muduo::string msg(buf->retrieveAllAsString());
//    //    LOG_INFO << conn->name() << " echo " << msg.size() << " bytes, "
//    //                     << "data received at " << time.toString();
//    //    conn->send(msg);
//    //    buf->retrieveAllAsString();
//    //    string str3;
//    //    str3.assign((char*)buffer, len);
//    //    pool.enqueue(do_rec,str3);
//    counttps++;
//    myPkg sen_pkg;
//    sen_pkg.set_encid(1);
//    sen_pkg.set_msgid(1);
//    sen_pkg.set_msgtype(CMP_RST);
//    sen_pkg.set_tmp("hhhhhhh");
//    sen_pkg.set_rst(123);
//    sen_pkg.set_cipher("");
//    sen_pkg.set_path("010101010");
//    std::string str;
//    sen_pkg.SerializeToString(&str);
//    gettimeofday(&qpsend,NULL);
//    conn->send(str);
////    do_rec(buf->retrieveAllAsString());
//}
//add end
//Server side
class SudokuServer
{
public:
    SudokuServer(EventLoop* loop, const InetAddress& listenAddr, int numThreads)
        : server_(loop, listenAddr, "SudokuServer"),
          numThreads_(numThreads),
          startTime_(Timestamp::now())
    {
        server_.setConnectionCallback(
                    std::bind(&SudokuServer::onConnection, this, _1));
        server_.setMessageCallback(
                    std::bind(&SudokuServer::onMessage, this, _1, _2, _3));
    }

    void start()
    {
        LOG_INFO << "starting " << numThreads_ << " threads.";
        threadPool_.start(numThreads_);
        server_.start();
    }

private:
    void onConnection(const TcpConnectionPtr& conn)
    {
        total_client_num++;
        addClientID(total_client_num-1,conn);
    }

    void onMessage(const TcpConnectionPtr& conn, Buffer* buf, Timestamp)
    {
//        counttps++;
//        if(counttps==1){
//            gettimeofday(&qpsstart,NULL);
//        }
//        conn->send(buf->retrieveAllAsString());
        threadPool_.run(std::bind(&solve, conn,buf->retrieveAllAsString()));
//        gettimeofday(&qpsend,NULL);
    }

    static void solve(const TcpConnectionPtr& conn,const string& input)
    {
        counttps++;
        if(counttps==1){
            gettimeofday(&qpsstart,NULL);
        }
        conn->send(input);
//        myPkg pkg;
//        pkg.ParseFromString(input);
//        if(pkg.msgtype()==CMP_RST)
//        {
//            int enc_id=pkg.encid();
//            mtx_list.lock();
//            rst_list[enc_id]=pkg;
//            //cout<<"push "<<enc_id<<" "<<rec_item.cipher<<endl;
//            mtx_list.unlock();
//        }
        gettimeofday(&qpsend,NULL);
    }

    TcpServer server_;
    ThreadPool threadPool_;
    int numThreads_;
    Timestamp startTime_;
};

int main(int argc, char *argv[])
{
    //    ConcurrentMap1 testmap;
    //    myPkg pkg;
    //    pkg.set_encid(1);
    //    pkg.set_msgid(1);
    //    pkg.set_msgtype(2);
    //    pkg.set_tmp("tmp");
    //    pkg.set_cipher("cipher");
    //    testmap.assign(1,&pkg);
    //    myPkg* get_pkg=testmap.get(1);
    //    cout<<"get pkg from map:"<<endl;
    //    cout<<get_pkg->encid()<<endl;
    //    cout<<get_pkg->cipher()<<endl;
    //    countMap.exchange(0,1);
    //    cout<<"before"<<countMap.get(0)<<endl;
    //    countMap.exchange(0,2);
    //     cout<<"after"<<countMap.get(0)<<endl;
    std::atomic<int> counttps;
    vector<int> cip_v;
    for(int i=0;i<TXN;i++)
    {
        cip_v.push_back(i);
    }
    random_shuffle(cip_v.begin(),cip_v.end());
    for(int i=0;i<TXN;i++)
    {
        string data="cipher"+to_string(cip_v[i]);
        enc_req enc;
        enc.id=i;
        enc.cipher=data;
        enc_queue.enqueue(enc);
    }
    root=new Node("cipher-1",-1);
    Node* node=new Node("cipher"+to_string(TXN),M);
    root->right=node;
    node->parent=root;

    char *serverIp = "127.0.0.1"; int port = 8085;
    int threadnum = 80;

    EventLoop loop;
    InetAddress addr("127.0.0.1", 8085);
    SudokuServer server(&loop, addr, threadnum);

    server.start();
    //HZC
    //    setloglevel("DEBUG");
    //    Signal::signal(SIGINT, [&]{ eventbase.exit(); });
    //    TcpServerPtr svr = TcpServer::startServer(&eventbase, "127.0.0.1", 8085,4);
    //    exitif(svr == NULL, "start tcp server failed");
    //    svr->onConnCreate([&] {
    //        TcpConnPtr con(new TcpConn);
    //        con->onState([&](const TcpConnPtr &con) {
    //            if (con->getState() == TcpConn::Connected) {
    //                total_client_num++;
    //                addClientID(total_client_num-1,con);
    //                eventbase.runAfter(0,[]() { do_encode(); });
    //                for(int i=0;i<100;i++){
    //                    myPkg pkg;
    //                    std::string str;
    //                    pkg.set_msgtype(REQ_CMP);
    //                    pkg.set_encid(1);
    //                    pkg.set_msgid(1);
    //                    pkg.set_tmp("tmp->cipher");
    //                    pkg.set_cipher("cipherx");
    //                    pkg.set_path("path");
    //                    pkg.SerializeToString(&str);
    //                    cout<<"------------send----------"<<endl;
    //                    cout<<"send:msgtyp="<<pkg.msgtype()<<endl;
    //                    cout<<"send:msgid="<<pkg.msgid()<<endl;
    //                    cout<<"send:encid="<<pkg.encid()<<endl;
    //                    cout<<"send:encid="<<pkg.tmp()<<endl;
    //                    cout<<"send:encid="<<pkg.cipher()<<endl;
    //                    cout<<"------------end----------"<<endl;
    //                    //HZC
    //                    clients[pkg.encid()%clients.size()]->sendMsg(str);
    //                    con->sendMsg(str);
    //                }

    //                //HZC
    ////                myPkg pkg;
    ////                                std::string str;
    ////                                pkg.set_msgtype(REQ_CMP);
    ////                                pkg.set_encid(1);
    ////                                pkg.set_msgid(1);
    ////                                pkg.set_tmp("tmp->cipher");
    ////                                pkg.set_cipher("cipherx");
    ////                                pkg.set_path("path");
    ////                                pkg.SerializeToString(&str);
    ////                                cout<<"------------send----------"<<endl;
    ////                                cout<<"send:msgtyp="<<pkg.msgtype()<<endl;
    ////                                cout<<"send:msgid="<<pkg.msgid()<<endl;
    ////                                cout<<"send:encid="<<pkg.encid()<<endl;
    ////                                cout<<"send:encid="<<pkg.tmp()<<endl;
    ////                                cout<<"send:encid="<<pkg.cipher()<<endl;
    ////                                cout<<"------------end----------"<<endl;
    ////                TcpConnPtr con1 = clients[1%clients.size()];
    ////                eventbase.runAfter(0,[con1,str]() { con1->sendMsg(str); });
    ////                return "";
    //            } else if (con->getState() == TcpConn::Closed) {
    //                //                users.erase(con->context<int>());
    //            }
    //        });
    //        con->onMsg(new LineCodec, [&](const TcpConnPtr &con, const string &input) {
    //        });
    //        return con;
    //    });
    //    auto service = TcpService::Create();
    //    service->startWorkerThread(4);


    //    auto enterCallback = [](const TcpConnection::Ptr& session) {
    //        cout<<"new client"<<endl;
    //        total_client_num++;
    //        clients[total_client_num-1]=session;

    //        session->setDataCallback([session](const char* buffer, size_t len) {
    //            //                   session->send(buffer, len);
    //            string str3;
    //            str3.assign((char*)buffer, len);
    ////            pool.enqueue(do_rec,str3);
    //            do_rec(str3);
    //            return len;
    //        });

    //        session->setDisConnectCallback([](const TcpConnection::Ptr& session) {
    //            total_client_num--;
    //        });
    //    };

    //    wrapper::ListenerBuilder listener;
    //    listener.configureService(service)
    //            .configureSocketOptions({
    //                                        [](TcpSocket& socket) {
    //                                            socket.setNodelay();
    //                                        }
    //                                    })
    //            .configureConnectionOptions({
    //                                            brynet::net::AddSocketOption::WithMaxRecvBufferSize(1024 * 1024),
    //                                            brynet::net::AddSocketOption::AddEnterCallback(enterCallback)
    //                                        })
    //            .configureListen([=](wrapper::BuildListenConfig config) {
    //        config.setAddr(false, serverIp, port);
    //    })
    //            .asyncRun();
    //    //HZC
    //    sleep(3);

    pthread_t tid1[NUM_ENCODE],tid3[EXE_TX],tid4[1];
    struct thread_data td1[NUM_ENCODE],td3[EXE_TX],td4[1];
    for(int i=0; i < NUM_ENCODE; i++ ){
        //         pool.enqueue(do_encodePool,1);
        td1[i].thread_id = i;
        td1[i].message="cipher"+to_string(i);
        //        if(i%2==0)
        //            td1[i].Sd = newSd;
        //        else
        //            td1[i].Sd = newSd1;
        int rc = pthread_create(&tid1[i], nullptr,do_encode, (void *)&td1[i]);
        pthread_detach(tid1[i]);
        if (rc){
            cout << "Error:unable to create thread," << rc << endl;
            exit(-1);
        }
    }
    //    //    myPkg pkg;
    //    //                    std::string str;
    //    //                    pkg.set_msgtype(REQ_CMP);
    //    //                    pkg.set_encid(1);
    //    //                    pkg.set_msgid(1);
    //    //                    pkg.set_tmp("tmp->cipher");
    //    //                    pkg.set_cipher("cipherx");
    //    //                    pkg.set_path("path");
    //    //                    pkg.SerializeToString(&str);
    //    //                    cout<<"------------send----------"<<endl;
    //    //                    cout<<"send:msgtyp="<<pkg.msgtype()<<endl;
    //    //                    cout<<"send:msgid="<<pkg.msgid()<<endl;
    //    //                    cout<<"send:encid="<<pkg.encid()<<endl;
    //    //                    cout<<"send:encid="<<pkg.tmp()<<endl;
    //    //                    cout<<"send:encid="<<pkg.cipher()<<endl;
    //    //                    cout<<"------------end----------"<<endl;
    //    //    TcpConnPtr con = clients[1%clients.size()];
    //    //    eventbase.runAfter(0,[con,str]() { con->sendMsg(str); });

    for(int i=0; i < EXE_TX; i++ ){
        //        pool.enqueue(write_treePool,1);
        td3[i].thread_id = i;
        int rc = pthread_create(&tid3[i], nullptr,write_tree, (void *)&td3[i]);
        pthread_detach(tid3[i]);
        if (rc){
            cout << "Error:unable to create thread," << rc << endl;
            exit(-1);
        }
    }

    //HZC
    for(int i=0; i < 1; i++ ){
        //        pool.enqueue(print_tpsPool,1);
        td4[i].thread_id = i;
        td4[i].message="cipher"+to_string(i);
        //        if(i%2==0)
        //            td1[i].Sd = newSd;
        //        else
        //            td1[i].Sd = newSd1;
        int rc = pthread_create(&tid4[i], nullptr,print_tps, (void *)&td4[i]);
        pthread_detach(tid4[i]);
        if (rc){
            cout << "Error:unable to create thread," << rc << endl;
            exit(-1);
        }
    }

    loop.loop();
    while(1){

    }

    //    EventLoop mainLoop;
    //    while (true)
    //    {
    //        mainLoop.loop(1000);
    //    }
    return 0;
}

#include <iostream>
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <mutex>
#include <time.h>
#include <algorithm>
#include <queue>
#include "tcp-Client.h"
using namespace std;
//add lqq

map<string,int64_t> text;//cipher-plain
//cache
map<int,int> cache;//plain-encode
std::mutex mtx_qryrst;
moodycamel::ConcurrentQueue<send_item> cmp_buffer;
std::map<int,send_item> qry_rst;
std::map<int,TcpConnectionPtr> servers;
EventLoop loop;
cool::ThreadPool pool(1);
int cmp_cli(string ciphertxt,string cipherx)
{
    if(text[cipherx]<-1 ||text[cipherx]>TXN)
        return ERR;
    return text[ciphertxt]-text[cipherx];
}
void cmp_cipher(send_item rec_item)
{
    if(rec_item.msg_type==REQ_CMP)
    {
        string tmp=rec_item.tmp;
        string cipherx=rec_item.cipher;
        string path=rec_item.path;
        int cmp=cmp_cli(tmp,cipherx);
        send_item sen_rst;
        sen_rst.enc_id=rec_item.enc_id;
        sen_rst.msg_id=rec_item.msg_id;
        sen_rst.msg_type=CMP_RST;
        sen_rst.tmp=tmp;
        sen_rst.rst=cmp;
        sen_rst.cipher=cipherx;
        if(cmp>0)
            path+="0";
        else
            path+="1";
        sen_rst.path=path;
        char msg[sen_rst.get_serialize_size()];
        memset(msg, 0, sizeof(msg));
        sen_rst.serialize(msg);
//        session->send(msg,sizeof(msg));
    }
    else
    {
        cerr<<"wong cmp type"<<endl;
    }

}
bool sortFunCip(const string &p1, const string &p2)
{
    string s1=p1;
    string s2=p2;
//    int c1=atoi(s1.substr(6).c_str());
//    int c2=atoi(s2.substr(6).c_str());
    int64_t c1=text[s1];
    int64_t c2=text[s2];
    return text[s1] < text[s2];//升序排列
}

#ifndef TCPCLIENT_H
#define TCPCLIENT_H
#include <queue>
#include <vector>
#include <map>
#include <string>
#include <mutex>
#include <utility>
#include "../common/proto_msg.h"
#include "../common/trans/msg.pb.h"
#include "../common/concurrentqueue.h"
#include "../common/threadpool.h"
#include "../common/util.h"
//#include <brynet/net/SocketLibFunction.hpp>
//#include <brynet/net/TcpService.hpp>
//#include <brynet/net/AsyncConnector.hpp>
//#include <brynet/net/wrapper/ConnectionBuilder.hpp>

//using namespace brynet;
//using namespace brynet::net;
#include <muduo/net/TcpServer.h>
#include <muduo/base/AsyncLogging.h>
#include <muduo/base/Logging.h>
#include <muduo/base/Thread.h>
#include <muduo/net/EventLoop.h>
#include <muduo/net/EventLoopThreadPool.h>
#include <muduo/base/ThreadPool.h>
#include <muduo/net/InetAddress.h>
#include <muduo/net/TcpClient.h>

using namespace muduo;
using namespace muduo::net;

using namespace std;
#define NUM_ENCODE 0
#define NUM_CMP 0
#define NUM_REC 3
#define NUM_QRY 0
//for encrypt and decrypt
extern map<string,int64_t> text;//cipher-plain
//cache
extern map<int,int> cache;//plain-encode
extern std::mutex mtx_qryrst;
extern moodycamel::ConcurrentQueue<send_item> cmp_buffer;
extern std::map<int,send_item> qry_rst;
extern cool::ThreadPool pool;
extern std::map<int,TcpConnectionPtr> servers;
extern EventLoop loop;
int cmp_cli(string ciphertxt,string cipherx);
void cmp_cipher(send_item rec_item);
bool sortFunCip(const string &p1, const string &p2);
#endif // TCPCLIENT_H

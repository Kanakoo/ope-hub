#!/bin/bash

for i in {1..100}
do
{
nohup ./client &
}
done

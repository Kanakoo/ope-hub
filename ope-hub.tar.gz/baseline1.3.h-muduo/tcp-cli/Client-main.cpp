#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <algorithm>
#include "tcp-Client.h"

using namespace muduo;
using namespace muduo::net;

void* do_rec(const string &input,const TcpConnectionPtr &conn)
{
    myPkg pkg;
    pkg.ParseFromString(input);

    myPkg sen_pkg;
    sen_pkg.set_encid(1);
    sen_pkg.set_msgid(2);
    sen_pkg.set_msgtype(CMP_RST);
    sen_pkg.set_tmp("tmp");
    sen_pkg.set_rst(3);
    sen_pkg.set_cipher("cipherx");
    sen_pkg.set_path("0101010101");
    std::string str;
    sen_pkg.SerializeToString(&str);
//    usleep(2000);
    conn->send(str);
//    //HZC
////    if(pkg.encid()==1000){
////        timeval temp;
////        gettimeofday(&temp,NULL);
////        cout<<temp.tv_sec<<" "<<temp.tv_usec<<endl;
////        cout<<pkg.msgid()<<endl;
////    }
//    //    cout<<"------------rec----------"<<endl;
//    //    cout<<"rec:msgtyp="<<pkg.msgtype()<<endl;
//    //    cout<<"rec:msgid="<<pkg.msgid()<<endl;
//    //    cout<<"rec:encid="<<pkg.encid()<<endl;
//    //    cout<<"rec:encid="<<pkg.tmp()<<endl;
//    //    cout<<"rec:encid="<<pkg.cipher()<<endl;
//    //    cout<<"------------end----------"<<endl;
//    if(pkg.msgtype()==REQ_CMP)
//    {
//        string tmp=pkg.tmp();
//        string cipherx=pkg.cipher();
//        string path=pkg.path();
//        int cmp=cmp_cli(tmp,cipherx);
//        myPkg sen_pkg;
//        sen_pkg.set_encid(pkg.encid());
//        sen_pkg.set_msgid(pkg.msgid());
//        sen_pkg.set_msgtype(CMP_RST);
//        sen_pkg.set_tmp(tmp);
//        sen_pkg.set_rst(cmp);
//        sen_pkg.set_cipher(cipherx);
//        if(cmp>0)
//            path+="0";
//        else
//            path+="1";
//        sen_pkg.set_path(path);
//        std::string str;
//        sen_pkg.SerializeToString(&str);
//        //        char * strc = new char[strlen(str.c_str())+1];
//        //        strcpy(strc, str.c_str());
//        conn->send(str);
//        //         string sendmsg = util::format("%.*s", sizeof(msg),msg);
//        //        eventbase.safeCall([msg,con]() { con->send(msg,sizeof(msg)); });
//        //cout<<"send msg:"<<my_data->Sd<<","<<sen_rst.cipher<<endl;

//    }
//    else
//    {
//        cerr<<"wrong message type when rec: "<<pkg.msgtype()<<endl;
//    }

//    //    send_item rec_item;
//    //    rec_item.deserialize(buffer);

//    //    if(rec_item.msg_type==REQ_CMP)
//    //    {
//    //        //cout<<"rec:"<<rec_item.cipher<<","<<rec_item.tmp<<","<<rec_item.msg_id<<endl;
//    //        cmp_buffer.enqueue(rec_item);
//    //    }
//    //    else
//    //    {
//    //        cerr<<"wrong message type when rec: "<<rec_item.msg_type<<endl;
//    //    }

}
void* do_cmp()
{
    while(1)
    {
        send_item rec_item;
        bool found=cmp_buffer.try_dequeue(rec_item);
        if(found)
        {
            cmp_cipher(rec_item);
        }
    }
}

//class Client;

//class Session : noncopyable
//{
//public:
//    Session(EventLoop* loop,
//            const InetAddress& serverAddr,
//            const string& name,
//            Client* owner)
//        : client_(loop, serverAddr, name),
//          owner_(owner),
//          bytesRead_(0),
//          bytesWritten_(0),
//          messagesRead_(0)
//    {
//        client_.setConnectionCallback(
//                    std::bind(&Session::onConnection, this, _1));
//        client_.setMessageCallback(
//                    std::bind(&Session::onMessage, this, _1, _2, _3));
//    }

//    void start()
//    {
//        client_.connect();
//    }

//    void stop()
//    {
//        client_.disconnect();
//    }

//    int64_t bytesRead() const
//    {
//        return bytesRead_;
//    }

//    int64_t messagesRead() const
//    {
//        return messagesRead_;
//    }

//private:

//    void onConnection(const TcpConnectionPtr& conn);

//    void onMessage(const TcpConnectionPtr& conn, Buffer* buf, Timestamp)
//    {
//        ++messagesRead_;
//        bytesRead_ += buf->readableBytes();
//        bytesWritten_ += buf->readableBytes();
//        do_rec(buf->retrieveAllAsString(),conn);
//    }

//    TcpClient client_;
//    Client* owner_;
//    int64_t bytesRead_;
//    int64_t bytesWritten_;
//    int64_t messagesRead_;
//};

//class Client : noncopyable
//{
//public:
//    Client(EventLoop* loop,
//           const InetAddress& serverAddr,
//           int blockSize,
//           int sessionCount,
//           int timeout,
//           int threadCount)
//        : loop_(loop),
//          threadPool_(loop, "pingpong-client"),
//          sessionCount_(sessionCount),
//          timeout_(timeout)
//    {
//        loop->runAfter(timeout, std::bind(&Client::handleTimeout, this));
//        if (threadCount > 1)
//        {
//            threadPool_.setThreadNum(threadCount);
//        }
//        threadPool_.start();

//        for (int i = 0; i < blockSize; ++i)
//        {
//            message_.push_back(static_cast<char>(i % 128));
//        }

//        for (int i = 0; i < sessionCount; ++i)
//        {
//            char buf[32];
//            snprintf(buf, sizeof buf, "C%05d", i);
//            Session* session = new Session(threadPool_.getNextLoop(), serverAddr, buf, this);
//            session->start();
//            sessions_.emplace_back(session);
//        }
//    }

//    const string& message() const
//    {
//        return message_;
//    }

//    void onConnect()
//    {
//        if (numConnected_.incrementAndGet() == sessionCount_)
//        {
//            LOG_WARN << "all connected";
//        }
//    }

//    void onDisconnect(const TcpConnectionPtr& conn)
//    {
//        if (numConnected_.decrementAndGet() == 0)
//        {
//            LOG_WARN << "all disconnected";

//            int64_t totalBytesRead = 0;
//            int64_t totalMessagesRead = 0;
//            for (const auto& session : sessions_)
//            {
//                totalBytesRead += session->bytesRead();
//                totalMessagesRead += session->messagesRead();
//            }
//            LOG_WARN << totalBytesRead << " total bytes read";
//            LOG_WARN << totalMessagesRead << " total messages read";
//            LOG_WARN << static_cast<double>(totalBytesRead) / static_cast<double>(totalMessagesRead)
//                     << " average message size";
//            LOG_WARN << static_cast<double>(totalBytesRead) / (timeout_ * 1024 * 1024)
//                     << " MiB/s throughput";
//            conn->getLoop()->queueInLoop(std::bind(&Client::quit, this));
//        }
//    }

//private:

//    void quit()
//    {
//        loop_->queueInLoop(std::bind(&EventLoop::quit, loop_));
//    }

//    void handleTimeout()
//    {
//        LOG_WARN << "stop";
//        for (auto& session : sessions_)
//        {
//            session->stop();
//        }
//    }

//    EventLoop* loop_;
//    EventLoopThreadPool threadPool_;
//    int sessionCount_;
//    int timeout_;
//    std::vector<std::unique_ptr<Session>> sessions_;
//    string message_;
//    AtomicInt32 numConnected_;
//};

//void Session::onConnection(const TcpConnectionPtr& conn)
//{
//    if (conn->connected())
//    {
////        conn->setTcpNoDelay(true);
////        conn->send(owner_->message());
//        owner_->onConnect();
//    }
//    else
//    {
//        owner_->onDisconnect(conn);
//    }
//}

//void onMessage(const TcpConnectionPtr &conn,
//               Buffer *buf,
//               Timestamp time)
//{
//    //    muduo::string msg(buf->retrieveAllAsString());
//    //    LOG_INFO << conn->name() << " echo " << msg.size() << " bytes, "
//    //                     << "data received at " << time.toString();
//    //    conn->send(msg);
//    //    buf->retrieveAllAsString();
//    //    string str3;
//    //    str3.assign((char*)buffer, len);
//    //    pool.enqueue(do_rec,str3);
////    loop.runAfter(0, do_rec(buf->retrieveAllAsString(),conn));
////    pool.enqueue([](const string &input,const TcpConnectionPtr &conn)
////    {
////        myPkg pkg;
////        pkg.ParseFromString(input);

////        myPkg sen_pkg;
////        sen_pkg.set_encid(1);
////        sen_pkg.set_msgid(2);
////        sen_pkg.set_msgtype(CMP_RST);
////        sen_pkg.set_tmp("tmp");
////        sen_pkg.set_rst(3);
////        sen_pkg.set_cipher("cipherx");
////        sen_pkg.set_path("0101010101");
////        std::string str;
////        sen_pkg.SerializeToString(&str);
////        usleep(2000);
////        conn->send(buf->retrieveAllAsString());
////                 },buf->retrieveAllAsString(),conn);
//}

class Session : noncopyable
{
 public:
  Session(EventLoop* loop,
          const InetAddress& serverAddr,
          const string& name, int numThreads)
    : client_(loop, serverAddr, name),
    numThreads_(numThreads)
  {
    client_.setConnectionCallback(
        std::bind(&Session::onConnection, this, _1));
    client_.setMessageCallback(
        std::bind(&Session::onMessage, this, _1, _2, _3));
  }

  void start()
  {
    threadPool_.start(numThreads_);
    client_.connect();
  }

  void stop()
  {
    client_.disconnect();
  }

 private:

  void onConnection(const TcpConnectionPtr& conn){

  };

  void onMessage(const TcpConnectionPtr& conn, Buffer* buf, Timestamp)
  {
      conn->send(buf->retrieveAllAsString());
//      usleep(200);
    threadPool_.run(std::bind(&solve, conn,buf->retrieveAllAsString()));
  }

  static void solve(const TcpConnectionPtr& conn,const string& input)
  {
      conn->send(input);
//      myPkg pkg;
//      pkg.ParseFromString(input);
//      if(pkg.msgtype()==REQ_CMP)
//      {
//          string tmp=pkg.tmp();
//          string cipherx=pkg.cipher();
//          string path=pkg.path();
//          int cmp=cmp_cli(tmp,cipherx);
//          myPkg sen_pkg;
//          sen_pkg.set_encid(pkg.encid());
//          sen_pkg.set_msgid(pkg.msgid());
//          sen_pkg.set_msgtype(CMP_RST);
//          sen_pkg.set_tmp(tmp);
//          sen_pkg.set_rst(cmp);
//          sen_pkg.set_cipher(cipherx);
//          if(cmp>0)
//              path+="0";
//          else
//              path+="1";
//          sen_pkg.set_path(path);
//          std::string str;
//          sen_pkg.SerializeToString(&str);
//          conn->send(str);
//      }
//      else
//      {
//          cerr<<"wrong message type when rec: "<<pkg.msgtype()<<endl;
//      }
  }

  TcpClient client_;
  ThreadPool threadPool_;
  int numThreads_;
};

int main(int argc, char *argv[])
{
    text.insert(pair<string,int64_t>("cipher-1",-1));
    text.insert(pair<string,int64_t>("cipher"+to_string(TXN),M));
    for(int i=0;i<TXN;i++)
        text.insert(pair<string,int>("cipher"+to_string(i),i));

    char *serverIp = "127.0.0.1"; int port = 8085;
    int threadnum = 4;

    InetAddress addr("127.0.0.1", 8085);
    Session client(&loop, addr, "echo_client",4);
    client.start();
    loop.loop();
    while(1){

    }
    //    EventLoop loop;
    //    InetAddress serverAddr(ip, port);

    //    Client client(&loop, serverAddr, blockSize, sessionCount, timeout, threadCount);
    //    loop.loop();
    //    setloglevel("DEBUG");
    //    Signal::signal(SIGINT, [&] { eventbase.exit(); });
    //    TcpConnPtr con = TcpConn::createConnection(&eventbase, "127.0.0.1", 8085);
    //    con->setReconnectInterval(3000);
    //    con->onMsg(new LineCodec, [&](const TcpConnPtr &con, const string &input) {
    //        myPkg pkg;
    //        pkg.ParseFromString(input);
    //        cout<<pkg.msgtype()<<endl;
    //         cout<<pkg.name()<<endl;
    //          cout<<pkg.id()<<endl;
    //           cout<<pkg.code()<<endl;
    //           int size=pkg.arr_size();
    //           for(int i=0;i<size;i++)
    //           cout<<pkg.arr(i)<<endl;
    //         do_rec(input,con);
    //    });
    //    con->onRead([&](const TcpConnPtr& con){
    //        if (ProtoMsgCodec::msgComplete(con->getInput())) {
    //                   Message *msg = ProtoMsgCodec::decode(con->getInput());
    //                   cout<<"ggg"<<endl;
    //                   msg
    //                   if (msg) {
    //                       dispatch.handle(con, msg);
    //                   } else {
    //                       error("bad msg from connection data");
    //                       con->close();
    //                   }
    //               }
    //    });
    //    con->onState([=](const TcpConnPtr &con) {
    //        if (con->getState() == TcpConn::Connected) {
    //            cout<<"connected"<<endl;
    //        }
    //    });
    //    eventbase.loop();
    //    info("program exited");

    //       auto service = TcpService::Create();
    //       service->startWorkerThread(4);

    //       auto connector = AsyncConnector::Create();
    //       connector->startWorkerThread();

    //       auto enterCallback = [](const TcpConnection::Ptr& session) {
    //           session->setDataCallback([session](const char* buffer, size_t len) {
    //                   /*cout<<"recv:"<<len<<endl*/;
    //                   string str3;
    //                   str3.assign((char*)buffer, len);
    ////                   pool.enqueue(do_rec,str3,session);
    //                   do_rec(str3,session);
    //                   return len;
    //               });
    //       };

    //       auto failedCallback = []() {
    //           std::cout << "connect failed" << std::endl;
    //       };

    //       wrapper::ConnectionBuilder connectionBuilder;
    //       connectionBuilder.configureService(service)
    //           .configureConnector(connector)
    //           .configureConnectionOptions({
    //               brynet::net::AddSocketOption::AddEnterCallback(enterCallback),
    //               brynet::net::AddSocketOption::WithMaxRecvBufferSize(1024 * 1024)
    //           });

    //       for (auto i = 0; i < 8; i++)
    //       {
    //           try
    //           {
    //               connectionBuilder.configureConnectOptions({
    //                       ConnectOption::WithAddr(serverIp, port),
    //                       ConnectOption::WithTimeout(std::chrono::seconds(10)),
    //                       ConnectOption::WithFailedCallback(failedCallback),
    //                       ConnectOption::AddProcessTcpSocketCallback([](TcpSocket& socket) {
    //                           socket.setNodelay();
    //                       })
    //                   })
    //                   .asyncConnect();
    //           }
    //           catch (std::runtime_error& e)
    //           {
    //               std::cout << "error:" << e.what() << std::endl;
    //           }
    //       }
    //   EventLoop mainLoop;
    //   while (true)
    //   {
    //       mainLoop.loop(1000);
    //   }
    return 0;
}

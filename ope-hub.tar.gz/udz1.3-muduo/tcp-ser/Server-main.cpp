#include <iostream>
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <math.h>
#include <mutex>
#include <time.h>
#include <queue>
#include <atomic>
#include <shared_mutex>
#include <assert.h>
#include <algorithm>
#include "tcp-Server.h"
using namespace std;

std::atomic_llong TotalRecvSize = ATOMIC_VAR_INIT(0);
std::atomic_llong total_client_num = ATOMIC_VAR_INIT(0);
std::atomic_llong total_packet_num = ATOMIC_VAR_INIT(0);
using namespace std;
using namespace muduo;
using namespace muduo::net;

void* write_tree(void *threadarg)
{
//        char *serverIp1 = "127.0.0.1"; int port1 =8081/* atoi(argv[2])*/;
//        struct hostent* host1 = gethostbyname(serverIp1);
//        sockaddr_in sendSockAddr1;
//        bzero((char*)&sendSockAddr1, sizeof(sendSockAddr1));
//        sendSockAddr1.sin_family = AF_INET;
//        sendSockAddr1.sin_addr.s_addr =inet_addr(inet_ntoa(*(struct in_addr*)*host1->h_addr_list));
//        sendSockAddr1.sin_port = htons(port1);
//        int clientSd1 = socket(AF_INET, SOCK_STREAM, 0);
//        //try to connect...
//        int status = connect(clientSd1,(sockaddr*) &sendSockAddr1, sizeof(sendSockAddr1));
//        if(status < 0)
//        {
//            cout<<"Error connecting to socket!"<<endl;
//        }
//        cout << "Connected to the Node!" << endl;
    //    while (1) {
    //        mtx_txqueue.lock();
    //        if(tx_buffer.size()>=TX_PER_BLOCK)
    //        {
    //            Block tx_block;
    //            tx_block.block_id=block_id;
    //            for(int i=0;i<TX_PER_BLOCK;i++)
    //            {
    //                Tx tx=tx_buffer.front();
    //                tx_buffer.pop();
    //                execute_tx(tx,tx_block);
    //            }
    //            mtx_txqueue.unlock();
    //            send_block(clientSd1,tx_block);
    //            tx_block.Print();
    //            int num=0;
    //            Print(num);
    //            block_id++;
    //        }
    //        else
    //        {
    //            mtx_txqueue.unlock();
    //        }

    //    }
    int nn=0;
    while(1)
    {

        Block tmp_block;
        int count = 0;
        while(1)
        {
            Tx tx;
            bool found=tx_buffer.try_dequeue(tx);
            if(found)
            {
                tmp_block.push(tx);
                nn++;
                count++;
                if(count>=TX_PER_BLOCK){
                    break;
                }
            }else{
                break;
            }
        }
        Block new_block;
        new_block.block_id=block_id;
        for(int i=0;i<tmp_block.n;i++){
            Tx tx1 = tmp_block.get(i);
            execute_by_type(tx1,new_block);
            gettimeofday(&myend,NULL);
        }
        if(new_block.n>0){
            usleep(10000);
//                       send_block(clientSd1,new_block);
            //            new_block.Print();
            //            int num=0;
            //            Print(num);
        }
        block_id++;

    }

}
void* do_encode(void *threadarg)
{
    sleep(3);
    struct thread_data *my_data;
    my_data = (struct thread_data *) threadarg;
    //cout << "Do Encode Thread ID : " << my_data->thread_id<<endl;
//    timeval start,end;
//    gettimeofday(&start,NULL);
    gettimeofday(&mystart,NULL);
    while(1)
    {
        while(is_reb)
        {

        }
        if(method==0)
        {
            if(nn>=TXN/3 /*&& udz_num<=0*/)
            {
                cout<<"------begin encode 1, nn="<<nn<<endl;
                method=1;
            }
        }

        is_enc=1;
        if(method)
        {
            Encode_m1();
        }
        else
        {
            Encode_m0();
        }
//        Encode_m0();
        is_enc=0;
        nn++;
    }
}

void* print_tps(void *threadarg){
    while(1){
        sleep(10);
        int num=0;
        Print(num);
//        num+=update_time;
        num+=update_time;
        abort_num=TXN-num;
        conflict_num=abort_num-reb_num;
        cout<<"abort num: "<<abort_num<<", conflict_num: "<<conflict_num<<", reb_num: "<<reb_num<<", update time: "<<update_time<<endl;
        float time_use=(myend.tv_sec-mystart.tv_sec)*1000000+(myend.tv_usec-mystart.tv_usec);//微秒
        printf("time_use is %f microseconds, tx num is %d, tps is about %f\n",time_use,num,(num+1)*1000000.0/time_use);
    }
}

void* do_rec(const string& input)
{
    myPkg pkg;
    pkg.ParseFromString(input);
    if(pkg.msgtype()==CMP_RST)
    {
        int enc_id=pkg.encid();
        //int msg_id=rec_item->msg_id;
        mtx_list.lock();
//        rst_list[enc_id]=pkg;
        rst_list[enc_id].push_back(pkg);
        //cout<<"push "<<enc_id<<" "<<rec_item.cipher<<endl;
        mtx_list.unlock();
    }
    else if(pkg.msgtype()==TX)
    {
        Tx tx;
        tx.tx_type=pkg.msgtype();
        tx.v_bef=pkg.vbef();
        tx.y=pkg.y();
        tx.cipher=pkg.cipher();
        tx.path=pkg.path();
        tx.mtd=pkg.mtd();
        tx_buffer.enqueue(tx);
    }
    else if(pkg.msgtype()==REB_TX)
    {
        Tx tx;
        tx.tx_type=pkg.msgtype();
        tx.v_bef=pkg.vbef();
        tx.cipher=pkg.cipher();
        tx.v_reb=pkg.vreb();
        tx.mtd=pkg.mtd();
        //add lqq
        tx.udzhash=pkg.udzhash();
        for(int i=0;i<pkg.allcip_size();i++)
        {
            if(pkg.allcip_size()>0)
            {
                tx.lz.list.push_back(Node(pkg.allcip(i),pkg.allenc(i)));
                //cout<<"tx left udz:"<<tx.lz.list[i].cipher<<", "<<tx.lz.list[i].code<<endl;
            }
        }
        tx_buffer.enqueue(tx);
    }
    else if(pkg.msgtype()==RESORT_TX)
    {
        Tx tx;
        tx.tx_type=pkg.msgtype();
        tx.v_bef=pkg.vbef();
        tx.path=pkg.path();
        tx.cipher=pkg.cipher();
        tx.mtd=pkg.mtd();
        int lsize=pkg.lcip_size();
        int rsize=pkg.rcip_size();
        for(int i=0;i<lsize;i++)
        {
            if(pkg.lcip(i).length()>0)
            {
                tx.lz.list.push_back(Node(pkg.lcip(i),pkg.lenc(i)));
                //cout<<"tx left udz:"<<tx.lz.list[i].cipher<<", "<<tx.lz.list[i].code<<endl;
            }
        }
        for(int i=0;i<rsize;i++)
        {
            if(pkg.rcip(i).length()>0)
            {
                tx.rz.list.push_back(Node(pkg.rcip(i),pkg.renc(i)));
                //cout<<"tx right udz:"<<tx.rz.list[i].cipher<<", "<<tx.rz.list[i].code<<endl;
            }
        }
        tx_buffer.enqueue(tx);
    }
    else
    {
        cerr<<"wrong message type when rec: "<<pkg.msgtype()<<endl;
    }
}

void onConnection(const TcpConnectionPtr &conn)
{
    total_client_num++;
    addClientID(total_client_num-1,conn);
//    LOG_INFO << "EchoServer - " << conn->peerAddress().toIpPort() << " -> "
//             << conn->localAddress().toIpPort() << " is "
//             << (conn->connected() ? "UP" : "DOWN");
}

void onMessage(const TcpConnectionPtr &conn,
               Buffer *buf,
               Timestamp time)
{
//    muduo::string msg(buf->retrieveAllAsString());
//    LOG_INFO << conn->name() << " echo " << msg.size() << " bytes, "
//                     << "data received at " << time.toString();
//    conn->send(msg);
//    buf->retrieveAllAsString();
//    string str3;
//    str3.assign((char*)buffer, len);
//    pool.enqueue(do_rec,str3);
    do_rec(buf->retrieveAllAsString());
}

//add end
//Server side
int main(int argc, char *argv[])
{
    vector<int> cip_v;
    for(int i=0;i<TXN;i++)
    {
        cip_v.push_back(i);
    }
    random_shuffle(cip_v.begin(),cip_v.end());
    for(int i=0;i<TXN;i++)
    {
        string data="cipher"+to_string(cip_v[i]);
        enc_req enc;
        enc.id=i;
        enc.cipher=data;
        enc_queue.enqueue(enc);
    }
    root=new Node("cipher-1",-1);
    Node* node=new Node("cipher"+to_string(TXN),M);
    root->right=node;
    node->parent=root;

    char *serverIp = "127.0.0.1"; int port = 8085;
    int threadnum = 6;

    EventLoop loop;
    InetAddress addr("127.0.0.1", 8085);
    TcpServer server(&loop, addr, "echo");
    server.setConnectionCallback(&onConnection);
    server.setMessageCallback(&onMessage);
    server.setThreadNum(threadnum);
    server.start();
    //HZC
//    vector<int> cip_v;
//    for(int i=0;i<N;i++)
//    {
//        cip_v.push_back(i);
//    }
//    random_shuffle(cip_v.begin(),cip_v.end());
//    for(int i=0;i<N;i++)
//    {
//        string data="cipher"+to_string(cip_v[i]);
//        enc_req enc;
//        enc.id=i;
//        enc.cipher=data;
//        enc_queue.enqueue(enc);
//    }
//    root=new Node("cipher-1",-1);
//    Node* node=new Node("cipher"+to_string(N),M);
//    root->right=node;
//    node->parent=root;

//    char *serverIp = "127.0.0.1"; int port = 8085;
//    auto service = TcpService::Create();
//    service->startWorkerThread(4);

//    auto enterCallback = [](const TcpConnection::Ptr& session) {
//        cout<<"new client"<<endl;
//        total_client_num++;
//        clients[total_client_num-1]=session;

//        session->setDataCallback([session](const char* buffer, size_t len) {
//            //                   session->send(buffer, len);
//            string str3;
//            str3.assign((char*)buffer, len);
//            do_rec(str3);
//            TotalRecvSize += len;
//            total_packet_num++;
//            return len;
//        });

//        session->setDisConnectCallback([](const TcpConnection::Ptr& session) {
//            total_client_num--;
//        });
//    };

//    wrapper::ListenerBuilder listener;
//    listener.configureService(service)
//            .configureSocketOptions({
//                                        [](TcpSocket& socket) {
//                                            socket.setNodelay();
//                                        }
//                                    })
//            .configureConnectionOptions({
//                                            brynet::net::AddSocketOption::WithMaxRecvBufferSize(1024 * 1024),
//                                            brynet::net::AddSocketOption::AddEnterCallback(enterCallback)
//                                        })
//            .configureListen([=](wrapper::BuildListenConfig config) {
//        config.setAddr(false, serverIp, port);
//    })
//            .asyncRun();
//    //HZC
//    sleep(3);

    pthread_t tid1[NUM_ENCODE],tid3[EXE_TX],tid4[1];
    struct thread_data td1[NUM_ENCODE],td3[EXE_TX],td4[1];
    for(int i=0; i < NUM_ENCODE; i++ ){
        td1[i].thread_id = i;
        td1[i].message="cipher"+to_string(i);
        int rc = pthread_create(&tid1[i], nullptr,do_encode, (void *)&td1[i]);
        pthread_detach(tid1[i]);
        if (rc){
            cout << "Error:unable to create thread," << rc << endl;
            exit(-1);
        }
    }




    for(int i=0; i < EXE_TX; i++ ){
        td3[i].thread_id = i;
        int rc = pthread_create(&tid3[i], nullptr,write_tree, (void *)&td3[i]);
        pthread_detach(tid3[i]);
        if (rc){
            cout << "Error:unable to create thread," << rc << endl;
            exit(-1);
        }
    }

    //HZC
    for(int i=0; i < 1; i++ ){
        td4[i].thread_id = i;
        td4[i].message="cipher"+to_string(i);
        //        if(i%2==0)
        //            td1[i].Sd = newSd;
        //        else
        //            td1[i].Sd = newSd1;
        int rc = pthread_create(&tid4[i], nullptr,print_tps, (void *)&td4[i]);
        pthread_detach(tid4[i]);
        if (rc){
            cout << "Error:unable to create thread," << rc << endl;
            exit(-1);
        }
    }

    loop.loop();
    while(1){

    }
    return 0;
}

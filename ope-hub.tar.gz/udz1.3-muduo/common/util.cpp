#include "util.h"
#include <unistd.h>
//int send_msg(int Sd,send_item& item)
//{
//    usleep(1);
//    char msg[item.get_serialize_size()];
//    memset(msg, 0, sizeof(msg));
//    item.serialize(msg);
//    int n=send(Sd, (char*)&msg, item.get_serialize_size(), 0);
//    //cout<<"send:"<<item.cipher<<","<<item.get_serialize_size()<<","<<n<<endl;
//    return n;
//}
//int rec_msg(int Sd,send_item& item)
//{
//    char msg[ITEM_SIZE];
//    memset(msg, 0, sizeof(msg));
//    int n=recv(Sd, (char*)&msg, ITEM_SIZE, 0);
//    item.deserialize(msg);
//    //cout<<"rec:"<<item.cipher<<","<<item.get_serialize_size()<<", "<<n<<endl;
//    return n;
//}
int send_block(int Sd,Block& block)
{
    usleep(1);
    char msg[BLOCK_SIZE];
    memset(msg, 0, sizeof(msg));
    block.serialize(msg);
    int n=send(Sd, (char*)&msg, block.get_serialize_size(), 0);
    //cout<<"block size:"<<block.get_serialize_size()<<","<<n<<endl;
    return n;
}
int rec_block(int Sd,Block& block)
{
    char msg[BLOCK_SIZE];
    memset(msg, 0, sizeof(msg));
    int n=recv(Sd, (char*)&msg, BLOCK_SIZE, 0);
    //cout<<"rrrrrrrrcv:"<<n<<endl;
    block.deserialize(msg);
    return n;
}
string compute_hash(vector<string> cips)
{
    int size=cips.size();
    string s="";
    for(int i=0;i<size;i++)
    {
        string ss=sha256(cips[i]);
        s+=ss;
    }
    return s;
}

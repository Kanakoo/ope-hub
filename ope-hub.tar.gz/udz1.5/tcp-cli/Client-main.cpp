#include <iostream>
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <mutex>
#include <time.h>
#include<algorithm>
#include <queue>
#include "tcp-Client.h"
using namespace std;
using namespace muduo;
using namespace muduo::net;

void* do_rec(const string& input,const TcpConnectionPtr &con)
{
    myPkg pkg;
    pkg.ParseFromString(input);
    if(pkg.msgtype()==REQ_CMP)
    {
        //cout<<"rec:"<<rec_item.enc_id<<","<<rec_item.msg_id<<","<<rec_item.cipher<<","<<rec_item.tmp<<endl;
        string tmp=pkg.tmp();
        string cipherx=pkg.cipher();
        string path=pkg.path();
        int cmp=cmp_cli(tmp,cipherx);
        myPkg sen_rst;
        sen_rst.set_encid(pkg.encid());
        sen_rst.set_msgid(pkg.msgid());
        sen_rst.set_msgtype(CMP_RST);
        sen_rst.set_tmp(tmp);
        sen_rst.set_rst(cmp);
        sen_rst.set_cipher(cipherx);
        sen_rst.set_mtd(pkg.mtd());
        if(cmp>0)
            path+="0";
        else if(cmp<0)
            path+="1";
        else
            path="0";
        sen_rst.set_path(path);
        std::string str;
        sen_rst.SerializeToString(&str);
        con->send(str);
    }
    else if(pkg.msgtype()==REB_TX)
    {
        myPkg sorted_item=pkg;
        sorted_item.clear_allcip();
        sorted_item.clear_allenc();
        vector<string> allcip;
        vector<int64_t> allenc;
        int all_size=pkg.allcip_size();
        for(int i=0;i<all_size;i++)
        {
//            if(pkg.allcip(i).length()>0)
//            {
                string s1=pkg.allcip(i);
                int e1=pkg.allenc(i);
                allcip.push_back(s1);
                allenc.push_back(e1);

//            }
        }
        sort(allcip.begin(),allcip.end(),sortFunCip);
        sort(allenc.begin(),allenc.end());
        assert(all_size==allcip.size());
        assert(all_size==allenc.size());
        for(int i=0;i<all_size;i++)
        {
            sorted_item.add_allcip(allcip[i]);
            sorted_item.add_allenc(allenc[i]);
        }

        std::string str;
        sorted_item.SerializeToString(&str);
        con->send(str);
    }
    else if(pkg.msgtype()==TX)
    {
        con->send(input);
    }
    else if(pkg.msgtype()==SORT_UDZ)
    {
        myPkg sorted_item=pkg;
        //sorted_item.Print();
        sorted_item.set_msgtype(RESORT_TX);
        vector<string> lcip;
        vector<int64_t> lenc;
        vector<string> rcip;
        vector<int64_t> renc;
        string path=sorted_item.path();
        char c=path[path.length()-1];
        if(c=='0')
        {
            sorted_item.clear_lcip();
            sorted_item.clear_lenc();
            int lsize=pkg.lcip_size();
            for(int i=0;i<lsize;i++)
            {
//                if(pkg.lcip(i).length()>0)
//                {
                    string s1=pkg.lcip(i);
                    int e1=pkg.lenc(i);
                    lcip.push_back(s1);
                    lenc.push_back(e1);
//                }
            }
            int l_size=lcip.size();
            assert(lsize==l_size);
            sort(lcip.begin(),lcip.end(),sortFunCip);
            sort(lenc.begin(),lenc.end());
            for(int i=0;i<l_size;i++)
            {
                //cout<<"----------lsort:"<<lcip[i]<<", "<<lenc[i]<<endl;
                sorted_item.add_lcip(lcip[i]);
                sorted_item.add_lenc(lenc[i]);
            }          
            std::string str;
            sorted_item.SerializeToString(&str);
            con->send(str);
        }
        else
        {
            sorted_item.clear_rcip();
            sorted_item.clear_renc();
            int rsize=pkg.rcip_size();
            for(int i=0;i<rsize;i++)
            {
//                if(pkg.rcip(i).length()>0)
//                {
                    string s2=pkg.rcip(i);
                    int e2=pkg.renc(i);
                    rcip.push_back(s2);
                    renc.push_back(e2);
                    //cout<<"right:"<<s2<<", "<<e2<<endl;

//                }
            }
            int r_size=rcip.size();
            assert(rsize==r_size);
            sort(rcip.begin(),rcip.end(),sortFunCip);
            sort(renc.begin(),renc.end());
            for(int i=0;i<r_size;i++)
            {
                //cout<<"----------rsort:"<<rcip[i]<<", "<<renc[i]<<endl;
                sorted_item.add_rcip(rcip[i]);
                sorted_item.add_renc(renc[i]);
            }
            std::string str;
            sorted_item.SerializeToString(&str);
            con->send(str);
        }
    }
    else
    {
        cerr<<"wrong message type when rec: "<<pkg.msgtype()<<endl;
    }

}

void onMessage(const TcpConnectionPtr &conn,
               Buffer *buf,
               Timestamp time)
{
    //    muduo::string msg(buf->retrieveAllAsString());
    //    LOG_INFO << conn->name() << " echo " << msg.size() << " bytes, "
    //                     << "data received at " << time.toString();
    //    conn->send(msg);
    //    buf->retrieveAllAsString();
    //    string str3;
    //    str3.assign((char*)buffer, len);
    //    pool.enqueue(do_rec,str3);
    do_rec(buf->retrieveAllAsString(),conn);
}

class Session : noncopyable
{
 public:
  Session(EventLoop* loop,
          const InetAddress& serverAddr,
          const string& name, int numThreads)
    : client_(loop, serverAddr, name),
    numThreads_(numThreads)
  {
    client_.setConnectionCallback(
        std::bind(&Session::onConnection, this, _1));
    client_.setMessageCallback(
        std::bind(&Session::onMessage, this, _1, _2, _3));
  }

  void start()
  {
    threadPool_.start(numThreads_);
    client_.connect();
  }

  void stop()
  {
    client_.disconnect();
  }

 private:

  void onConnection(const TcpConnectionPtr& conn){
//      string data="cipher"+to_string(cip_v[i]);
//      enc_req enc;
//      enc.id=i;
//      enc.cipher=data;
//      enc_queue.enqueue(enc);
      for(int i=clientId*32;i<(clientId+1)*32;i++)
      {
          cout<<"send "<<i<<","<<enc_map[i]<<endl;
          myPkg pkg;
          pkg.set_msgtype(REQ_ENC);
          pkg.set_encid(i);
          pkg.set_cipher(enc_map[i]);
          std::string str;
          pkg.SerializeToString(&str);
          usleep(50000);
          conn->send(str);
      }

  }

  void onMessage(const TcpConnectionPtr& conn, Buffer* buf, Timestamp)
  {
//      conn->send(buf->retrieveAllAsString());
//      usleep(200);
    threadPool_.run(std::bind(&client_rec, conn,buf->retrieveAllAsString()));
  }

  static void client_rec(const TcpConnectionPtr &con,const string& input)
  {
      myPkg pkg;
      pkg.ParseFromString(input);
      if(pkg.msgtype()==REQ_CMP)
      {
          cout<<"hhh1"<<endl;
//          cout<<"rec:"<<rec_item.enc_id<<","<<rec_item.msg_id<<","<<rec_item.cipher<<","<<rec_item.tmp<<endl;
          string tmp=pkg.tmp();
          string cipherx=pkg.cipher();
          string path=pkg.path();
          int cmp=cmp_cli(tmp,cipherx);
          myPkg sen_rst;
          sen_rst.set_encid(pkg.encid());
          sen_rst.set_msgid(pkg.msgid());
          sen_rst.set_msgtype(CMP_RST);
          sen_rst.set_tmp(tmp);
          sen_rst.set_rst(cmp);
          sen_rst.set_cipher(cipherx);
          sen_rst.set_mtd(pkg.mtd());
          if(cmp>0)
              path+="0";
          else if(cmp<0)
              path+="1";
          else
              path="0";
          sen_rst.set_path(path);
          std::string str;
          sen_rst.SerializeToString(&str);
          con->send(str);
      }
      else if(pkg.msgtype()==REB_TX)
      {
          cout<<"hhh2"<<endl;
          myPkg sorted_item=pkg;
          sorted_item.clear_allcip();
          sorted_item.clear_allenc();
          vector<string> allcip;
          vector<int64_t> allenc;
          int all_size=pkg.allcip_size();
          for(int i=0;i<all_size;i++)
          {
  //            if(pkg.allcip(i).length()>0)
  //            {
                  string s1=pkg.allcip(i);
                  int e1=pkg.allenc(i);
                  allcip.push_back(s1);
                  allenc.push_back(e1);

  //            }
          }
          sort(allcip.begin(),allcip.end(),sortFunCip);
          sort(allenc.begin(),allenc.end());
          assert(all_size==allcip.size());
          assert(all_size==allenc.size());
          for(int i=0;i<all_size;i++)
          {
              sorted_item.add_allcip(allcip[i]);
              sorted_item.add_allenc(allenc[i]);
          }

          std::string str;
          sorted_item.SerializeToString(&str);
          con->send(str);
      }
      else if(pkg.msgtype()==TX)
      {
          cout<<"hhh3"<<endl;
          con->send(input);
      }
      else if(pkg.msgtype()==SORT_UDZ)
      {
          cout<<"hhh4"<<endl;
          myPkg sorted_item=pkg;
          //sorted_item.Print();
          sorted_item.set_msgtype(RESORT_TX);
          vector<string> lcip;
          vector<int64_t> lenc;
          vector<string> rcip;
          vector<int64_t> renc;
          string path=sorted_item.path();
          char c=path[path.length()-1];
          if(c=='0')
          {
              sorted_item.clear_lcip();
              sorted_item.clear_lenc();
              int lsize=pkg.lcip_size();
              for(int i=0;i<lsize;i++)
              {
  //                if(pkg.lcip(i).length()>0)
  //                {
                      string s1=pkg.lcip(i);
                      int e1=pkg.lenc(i);
                      lcip.push_back(s1);
                      lenc.push_back(e1);
  //                }
              }
              int l_size=lcip.size();
              assert(lsize==l_size);
              sort(lcip.begin(),lcip.end(),sortFunCip);
              sort(lenc.begin(),lenc.end());
              for(int i=0;i<l_size;i++)
              {
                  //cout<<"----------lsort:"<<lcip[i]<<", "<<lenc[i]<<endl;
                  sorted_item.add_lcip(lcip[i]);
                  sorted_item.add_lenc(lenc[i]);
              }
              std::string str;
              sorted_item.SerializeToString(&str);
              con->send(str);
          }
          else
          {
              cout<<"hhh5"<<endl;
              sorted_item.clear_rcip();
              sorted_item.clear_renc();
              int rsize=pkg.rcip_size();
              for(int i=0;i<rsize;i++)
              {
  //                if(pkg.rcip(i).length()>0)
  //                {
                      string s2=pkg.rcip(i);
                      int e2=pkg.renc(i);
                      rcip.push_back(s2);
                      renc.push_back(e2);
                      //cout<<"right:"<<s2<<", "<<e2<<endl;

  //                }
              }
              int r_size=rcip.size();
              assert(rsize==r_size);
              sort(rcip.begin(),rcip.end(),sortFunCip);
              sort(renc.begin(),renc.end());
              for(int i=0;i<r_size;i++)
              {
                  //cout<<"----------rsort:"<<rcip[i]<<", "<<renc[i]<<endl;
                  sorted_item.add_rcip(rcip[i]);
                  sorted_item.add_renc(renc[i]);
              }
              std::string str;
              sorted_item.SerializeToString(&str);
              con->send(str);
          }
      }
      else
      {
          cerr<<"wrong message type when rec: "<<pkg.msgtype()<<endl;
      }

  }

  static void solve(const TcpConnectionPtr& conn,const string& input)
  {
      conn->send(input);
//      myPkg pkg;
//      pkg.ParseFromString(input);
//      if(pkg.msgtype()==REQ_CMP)
//      {
//          string tmp=pkg.tmp();
//          string cipherx=pkg.cipher();
//          string path=pkg.path();
//          int cmp=cmp_cli(tmp,cipherx);
//          myPkg sen_pkg;
//          sen_pkg.set_encid(pkg.encid());
//          sen_pkg.set_msgid(pkg.msgid());
//          sen_pkg.set_msgtype(CMP_RST);
//          sen_pkg.set_tmp(tmp);
//          sen_pkg.set_rst(cmp);
//          sen_pkg.set_cipher(cipherx);
//          if(cmp>0)
//              path+="0";
//          else
//              path+="1";
//          sen_pkg.set_path(path);
//          std::string str;
//          sen_pkg.SerializeToString(&str);
//          conn->send(str);
//      }
//      else
//      {
//          cerr<<"wrong message type when rec: "<<pkg.msgtype()<<endl;
//      }
  }

  TcpClient client_;
  ThreadPool threadPool_;
  int numThreads_;
};

int main(int argc, char *argv[])
{
    text.insert(pair<string,int64_t>("cipher-1",-1));
    text.insert(pair<string,int64_t>("cipher"+to_string(TXN),M));
    for(int i=0;i<TXN;i++)
        text.insert(pair<string,int>("cipher"+to_string(i),i));

    clientId = atoi(argv[1]);
    vector<int> cip_v;
    for(int i=0;i<TXN;i++)
    {
        cip_v.push_back(i);
    }
    random_shuffle(cip_v.begin(),cip_v.end());
    for(int i=0;i<TXN;i++)
    {
        string data="cipher"+to_string(cip_v[i]);
        enc_map[i]=data;
    }

    char *serverIp = "127.0.0.1"; int port = 8085;
    int threadnum = 6;

    EventLoop loop;
    InetAddress addr("127.0.0.1", 8085);
    Session client(&loop, addr, "echo_client",32);
    client.start();
    loop.loop();
    while(1){

    }
//    text.insert(pair<string,int64_t>("cipher-1",-1));
//    text.insert(pair<string,int64_t>("cipher"+to_string(N),M));
//    for(int i=0;i<N;i++)
//        text.insert(pair<string,int>("cipher"+to_string(i),i));
//    char *serverIp = "127.0.0.1"; int port = 8085;
//    int threadnum = 4;

//    auto service = TcpService::Create();
//    service->startWorkerThread(4);

//    auto connector = AsyncConnector::Create();
//    connector->startWorkerThread();

//    auto enterCallback = [](const TcpConnection::Ptr& session) {
//        session->setDataCallback([session](const char* buffer, size_t len) {
//            /*cout<<"recv:"<<len<<endl*/;
//            string str3;
//            str3.assign((char*)buffer, len);
//            do_rec(str3,session);
//            return len;
//        });
//    };

//    auto failedCallback = []() {
//        std::cout << "connect failed" << std::endl;
//    };

//    wrapper::ConnectionBuilder connectionBuilder;
//    connectionBuilder.configureService(service)
//            .configureConnector(connector)
//            .configureConnectionOptions({
//                                            brynet::net::AddSocketOption::AddEnterCallback(enterCallback),
//                                            brynet::net::AddSocketOption::WithMaxRecvBufferSize(1024 * 1024)
//                                        });

//    for (auto i = 0; i < 8; i++)
//    {
//        try
//        {
//            connectionBuilder.configureConnectOptions({
//                                                          ConnectOption::WithAddr(serverIp, port),
//                                                          ConnectOption::WithTimeout(std::chrono::seconds(10)),
//                                                          ConnectOption::WithFailedCallback(failedCallback),
//                                                          ConnectOption::AddProcessTcpSocketCallback([](TcpSocket& socket) {
//                                                              socket.setNodelay();
//                                                          })
//                                                      })
//                    .asyncConnect();
//        }
//        catch (std::runtime_error& e)
//        {
//            std::cout << "error:" << e.what() << std::endl;
//        }
//    }
//    EventLoop mainLoop;
//    while (true)
//    {
//        mainLoop.loop(1000);
//    }
    return 0;
}

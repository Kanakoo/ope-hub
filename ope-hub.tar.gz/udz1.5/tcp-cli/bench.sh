#!/bin/bash

for i in {0..255}
do
{
nohup ./client i &
}
done

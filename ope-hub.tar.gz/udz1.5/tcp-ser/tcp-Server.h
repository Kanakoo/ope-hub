#ifndef TCPSERVER_H
#define TCPSERVER_H
#include "../common/trans/msg.pb.h"
#include "../common/concurrentqueue.h"
#include <iostream>
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <math.h>
#include <mutex>
#include <time.h>
#include <queue>
#include <atomic>
#include <shared_mutex>
#include <assert.h>
#include <algorithm>
#include "../common/util.h"

using namespace std;

#include <muduo/net/TcpServer.h>
#include <muduo/base/AsyncLogging.h>
#include <muduo/base/Logging.h>
#include <muduo/base/Thread.h>
#include <muduo/net/EventLoop.h>
#include <muduo/base/ThreadPool.h>
#include <muduo/net/InetAddress.h>

using namespace muduo;
using namespace muduo::net;

//add lqq
//variables
#define NUM_ENCODE 10
#define EXE_TX 1
#define NUM_REC 500
#define NUM_QRY 0
extern std::atomic<bool> is_reb;
extern std::atomic<bool> is_enc;
extern std::mutex mtx_list;
extern std::atomic<int> version;
extern std::atomic<int> version_reb;
extern std::atomic<int> abort_num;
extern std::atomic<int> conflict_num;
extern std::atomic<int> reb_num;
extern std::atomic<int> counttps;
extern std::atomic<bool> method;
extern std::atomic<int> nn;
extern Node* root;
extern std::atomic<int> update_time;
//HZC
extern std::map<int,std::vector<myPkg>> rst_list;
//extern std::map<int,myPkg> rst_list;
//extern std::map<int,myPkg> rst_list;
extern moodycamel::ConcurrentQueue<enc_req> enc_queue;
extern moodycamel::ConcurrentQueue<Tx> tx_buffer;
extern Block tx_block;
extern std::atomic<int> block_id;
//HZC
extern timeval mystart;
extern timeval myend;
extern timeval qpsstart;
extern timeval qpsend;
void quicksort(vector<string>& tmp_list,map<string,int64_t>& tmp_map,int low, int high);
void Inorder(Node* node,vector<string>& tmp_list,map<string,int64_t>& tmp_map);
void Inorder(vector<string>& tmp_list,map<string,int64_t>& tmp_map, vector<Node>& all_udz);
void Inorder1(Node* node,int& num);
void Print(int& num);
void Inorder2(Node* node,myPkg& item,string& hash,int& k);
void get_all_udz(myPkg& item,string&hash,int& k);
void Inorder3(Node* node,int& num);
void get_all_num(int& num);

//HZC
//extern std::vector<TcpConnection::Ptr> clients;
//extern TcpService::Ptr service;
extern std::map<int,TcpConnectionPtr> clients;
//extern EventBase eventbase;
//HZC
//void addClientID(int index,const TcpConnection::Ptr &con);
//void removeClientID(const TcpConnection::Ptr &con);

void addClientID(int index, const TcpConnectionPtr &con);
void destory(Node*& p);
void destory();
void Update(vector<string>& data,map<string,int64_t>& tmp_map);
//int Encode(int newSd);
void execute_tx_m0(Tx& tx,Block& tx_block);
int Encode1(string current,map<string,int64_t>& tmp_map);
int Encode_m0(int enc_id,string cipherx);
//change next
int Encode_m1(int enc_id,string cipherx);
void execute_tx_m1(Tx& tx,Block& tx_block);
void execute_by_type(Tx& tx,Block& tx_block);
void Inorder4(Node* node,vector<string>& tmp_list,map<string,int64_t>& tmp_map);
void Inorder4(vector<string>& tmp_list,map<string,int64_t>& tmp_map);
#endif // TCPSERVER_H

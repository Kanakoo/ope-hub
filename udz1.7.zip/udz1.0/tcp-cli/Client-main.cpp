#include <iostream>
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <mutex>
#include <time.h>
#include <algorithm>
#include <queue>
#include "tcp-Client.h"
using namespace std;
// using namespace muduo;
// using namespace muduo::net;

void* do_rec(void *threadarg)
{
    struct thread_data *my_data;
    my_data = (struct thread_data *) threadarg;
    while(1)
    {
        myPkg pkg;
        int n=rec_msg(my_data->Sd,pkg);
        if(n>0)
        {
            if(pkg.msgtype()==REQ_CMP)
            {
                //cout<<"rec:"<<rec_item.enc_id<<","<<rec_item.msg_id<<","<<rec_item.cipher<<","<<rec_item.tmp<<endl;
                string tmp=pkg.tmp();
                string cipherx=pkg.cipher();
                string path=pkg.path();
                int cmp=cmp_cli(tmp,cipherx);
                myPkg sen_rst;
                sen_rst.set_encid(pkg.encid());
                sen_rst.set_msgid(pkg.msgid());
                sen_rst.set_msgtype(CMP_RST);
                sen_rst.set_tmp(tmp);
                sen_rst.set_rst(cmp);
                sen_rst.set_cipher(cipherx);
                sen_rst.set_mtd(pkg.mtd());
                if(cmp>0)
                    path+="0";
                else if(cmp<0)
                    path+="1";
                else
                    path="0";
                sen_rst.set_path(path);
                send_msg(my_data->Sd,sen_rst);
            }
            else if(pkg.msgtype()==REB_TX)
            {
                if(pkg.mtd()==1)
                {
//                    cout<<"mtd 1"<<endl;
                    send_msg(my_data->Sd,pkg);
                }
                else
                {
                    myPkg sorted_item=pkg;
                    sorted_item.clear_allcip();
                    sorted_item.clear_allenc();
                    vector<string> allcip;
                    vector<int64_t> allenc;
                    int all_size=pkg.allcip_size();
                    for(int i=0;i<all_size;i++)
                    {
                        string s1=pkg.allcip(i);
                        int e1=pkg.allenc(i);
                        allcip.push_back(s1);
                        allenc.push_back(e1);

                    }
                    sort(allcip.begin(),allcip.end(),sortFunCip);
                    sort(allenc.begin(),allenc.end());
                    assert(all_size==allcip.size());
                    assert(all_size==allenc.size());
                    for(int i=0;i<all_size;i++)
                    {
                        sorted_item.add_allcip(allcip[i]);
                        sorted_item.add_allenc(allenc[i]);
                    }
                    send_msg(my_data->Sd,sorted_item);
                }

            }
            else if(pkg.msgtype()==TX)
            {
                if(pkg.mtd()==1)
                {
//                    cout<<"mtd 1"<<endl;
                    send_msg(my_data->Sd,pkg);
                }
            }
            else if(pkg.msgtype()==SORT_UDZ)
            {
                myPkg sorted_item=pkg;
                sorted_item.set_msgtype(RESORT_TX);
                vector<string> lcip;
                vector<int64_t> lenc;
                vector<string> rcip;
                vector<int64_t> renc;
                string path=sorted_item.path();
                char c=path[path.length()-1];
                if(c=='0')
                {
                    sorted_item.clear_lcip();
                    sorted_item.clear_lenc();
                    int lsize=pkg.lcip_size();
                    for(int i=0;i<lsize;i++)
                    {
                        string s1=pkg.lcip(i);
                        int e1=pkg.lenc(i);
                        lcip.push_back(s1);
                        lenc.push_back(e1);
                    }
                    int l_size=lcip.size();
                    assert(lsize==l_size);
                    sort(lcip.begin(),lcip.end(),sortFunCip);
                    sort(lenc.begin(),lenc.end());
                    for(int i=0;i<l_size;i++)
                    {
                        sorted_item.add_lcip(lcip[i]);
                        sorted_item.add_lenc(lenc[i]);
                    }
                    send_msg(my_data->Sd,sorted_item);
                }
                else
                {
                    sorted_item.clear_rcip();
                    sorted_item.clear_renc();
                    int rsize=pkg.rcip_size();
                    for(int i=0;i<rsize;i++)
                    {
                        string s2=pkg.rcip(i);
                        int e2=pkg.renc(i);
                        rcip.push_back(s2);
                        renc.push_back(e2);
                    }
                    int r_size=rcip.size();
                    assert(rsize==r_size);
                    sort(rcip.begin(),rcip.end(),sortFunCip);
                    sort(renc.begin(),renc.end());
                    for(int i=0;i<r_size;i++)
                    {
                        //cout<<"----------rsort:"<<rcip[i]<<", "<<renc[i]<<endl;
                        sorted_item.add_rcip(rcip[i]);
                        sorted_item.add_renc(renc[i]);
                    }
                    send_msg(my_data->Sd,sorted_item);
                }
            }
            else
            {
                cerr<<"wrong message type when rec: "<<pkg.msgtype()<<endl;
            }

        }
    }
}

int main(int argc, char *argv[])
{
    text.insert(pair<string,int64_t>("cipher-1",-1));
    text.insert(pair<string,int64_t>("cipher"+to_string(TXN),M));
    for(int i=0;i<TXN;i++)
        text.insert(pair<string,int>("cipher"+to_string(i),i));
    char *serverIp = "127.0.0.1"; int port =8080/* atoi(argv[2])*/;
    //create a message buffer

    //setup a socket and connection tools
    struct hostent* host = gethostbyname(serverIp);
    sockaddr_in sendSockAddr;
    bzero((char*)&sendSockAddr, sizeof(sendSockAddr));
    sendSockAddr.sin_family = AF_INET;
    sendSockAddr.sin_addr.s_addr =
            inet_addr(inet_ntoa(*(struct in_addr*)*host->h_addr_list));
    sendSockAddr.sin_port = htons(port);
    int clientSd = socket(AF_INET, SOCK_STREAM, 0);
    //try to connect...
    int status = connect(clientSd,
                         (sockaddr*) &sendSockAddr, sizeof(sendSockAddr));
    if(status < 0)
    {
        cout<<"Error connecting to socket!"<<endl;return -1;
    }
    cout << "Connected to the server!" << endl;
    pthread_t tid3[NUM_REC];
    struct thread_data td3[NUM_REC];
    for(int i=0; i < NUM_REC; i++ ){
        td3[i].thread_id = i;
        td3[i].Sd = clientSd;
        int rc = pthread_create(&tid3[i], NULL,do_rec, (void *)&td3[i]);
        pthread_detach(tid3[i]);
        if (rc){
            cout << "Error:unable to create thread," << rc << endl;
            exit(-1);
        }
    }
    //test serialize
    //    for(int i=0;i<N;i++)
    //    {
    //        sleep(1);
    //        string data="cipher"+to_string(i);
    //        send_item encode_item("encode",data);
    //        send_msg(clientSd,encode_item);

    //    }
    while(1)
    {

    }
    close(clientSd);
    pthread_exit(NULL);
    return 0;
}

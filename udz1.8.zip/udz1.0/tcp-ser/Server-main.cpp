#include <iostream>
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <math.h>
#include <mutex>
#include <time.h>
#include <queue>
#include <atomic>
#include <shared_mutex>
#include <assert.h>
#include <algorithm>
#include "tcp-Server.h"
using namespace std;

std::atomic_llong TotalRecvSize = ATOMIC_VAR_INIT(0);
std::atomic_llong total_client_num = ATOMIC_VAR_INIT(0);
std::atomic_llong total_packet_num = ATOMIC_VAR_INIT(0);
using namespace std;
void* do_query(void *threadarg)
{
    struct thread_data *my_data;
    my_data = (struct thread_data *) threadarg;
    sleep(8);
//    int64_t left=40000000,right=400000000;
//    cout << "*****************begin query : " <<left<<","<<right<<endl;
    std::vector<string> qry_rst;
    //            searchRangeByCode(left,right,qry_rst);
    //            cout<<qry_rst.size()<<endl;
    //            for(int i=0;i<qry_rst.size();i++)
    //                cout<<"result "<<qry_rst[i]<<endl;
    qry_rst.clear();
    searchRangeByCipher(my_data->Sd,"cipher100","cipher500",qry_rst);
    for(int i=0;i<qry_rst.size();i++)
        cout<<"result "<<qry_rst[i]<<endl;
}
void* write_tree(void *threadarg)
{
//    char *serverIp1 = "127.0.0.1"; int port1 =8081/* atoi(argv[2])*/;
//    struct hostent* host1 = gethostbyname(serverIp1);
//    sockaddr_in sendSockAddr1;
//    bzero((char*)&sendSockAddr1, sizeof(sendSockAddr1));
//    sendSockAddr1.sin_family = AF_INET;
//    sendSockAddr1.sin_addr.s_addr =inet_addr(inet_ntoa(*(struct in_addr*)*host1->h_addr_list));
//    sendSockAddr1.sin_port = htons(port1);
//    int clientSd1 = socket(AF_INET, SOCK_STREAM, 0);
//    //try to connect...
//    int status = connect(clientSd1,(sockaddr*) &sendSockAddr1, sizeof(sendSockAddr1));
//    if(status < 0)
//    {
//        cout<<"Error connecting to socket!"<<endl;
//    }
//    cout << "Connected to the Node!" << endl;
    int nn=0;
    while(1)
    {

        Block tmp_block;
        int count = 0;
        while(1)
        {
            Tx tx;
            bool found=tx_buffer.try_dequeue(tx);
            if(found)
            {
                tmp_block.push(tx);
                nn++;
                count++;
                if(count>=TX_PER_BLOCK){
                    break;
                }
            }else{
                break;
            }
        }
        Block new_block;
        new_block.block_id=block_id;
        for(int i=0;i<tmp_block.n;i++){
            Tx tx1 = tmp_block.get(i);
            execute_by_type(tx1,new_block);
            gettimeofday(&myend,NULL);
        }
        if(new_block.n>0){
//            send_block(clientSd1,new_block);
            usleep(100000);
        }
        block_id++;

    }

}
void* do_encode(void *threadarg)
{
    struct thread_data *my_data;
    my_data = (struct thread_data *) threadarg;
    //cout << "Do Encode Thread ID : " << my_data->thread_id<<endl;
//    timeval start,end;
//    gettimeofday(&start,NULL);
    gettimeofday(&mystart,NULL);
    while(1)
    {
        while(is_reb)
        {

        }
//        if(method==0)
//        {
//            if(nn>=TXN/2)
//            {
//                cout<<"------begin encode 1, nn="<<nn<<endl;
//                method=1;
//            }
//        }

        is_enc=1;
//        if(method)
//        {
//            Encode_m1(my_data->Sd);
//        }
//        else
//        {
//            Encode_m0(my_data->Sd);
//        }
        Encode_m1(my_data->Sd);
        is_enc=0;
        nn++;
    }
}

void print_tps()
{
//    while(1){
        sleep(5);
        int num=0;
        Print(num);
        num+=update_time;
        abort_num=TXN-num;
        conflict_num=abort_num-reb_num;
        cout<<"total num: "<<num<<endl;
        cout<<"abort num: "<<abort_num<<", conflict_num: "<<conflict_num<<", reb_num: "<<reb_num<<", update time: "<<update_time<<endl;
        float time_use=(myend.tv_sec-mystart.tv_sec)*1000000+(myend.tv_usec-mystart.tv_usec);//微秒
        printf("time_use is %f microseconds, tx num is %d, tps is about %f\n",time_use,num,(num+1)*1000000.0/time_use);
//    }
}

void* do_rec(void *threadarg)
{
    struct thread_data *my_data;
    my_data = (struct thread_data *) threadarg;
    while(1)
    {
       myPkg pkg;
       int n=rec_msg(my_data->Sd,pkg);
       if(n>0)
       {
           if(pkg.msgtype()==CMP_RST)
           {
               int enc_id=pkg.encid();
               vector<myPkg> tmpv;
               rst_list.find(enc_id,tmpv);
               tmpv.push_back(pkg);
               rst_list.insert(enc_id,tmpv);
           }
           else if(pkg.msgtype()==QRY_RST)
           {
                qry_rst.enqueue(pkg);
           }
           else if(pkg.msgtype()==TX)
           {
               Tx tx;
               tx.tx_type=pkg.msgtype();
               tx.v_bef=pkg.vbef();
               tx.y=pkg.y();
               tx.cipher=pkg.cipher();
               tx.path=pkg.path();
               tx.mtd=pkg.mtd();
               tx_buffer.enqueue(tx);
           }
           else if(pkg.msgtype()==REB_TX)
           {
               if(pkg.mtd()==1)
               {
                   Tx tx;
                   tx.mtd=1;
                   tx.tx_type=pkg.msgtype();
                   tx_buffer.enqueue(tx);
               }
               else
               {
                   Tx tx;
                   tx.tx_type=pkg.msgtype();
                   tx.v_udz=pkg.vudz();
                   tx.cipher=pkg.cipher();
                   tx.mtd=pkg.mtd();
                   for(int i=0;i<pkg.allcip_size();i++)
                   {
                       if(pkg.allcip_size()>0)
                       {
                           tx.lz.list.push_back(Node(pkg.allcip(i),pkg.allenc(i)));
                           //cout<<"tx left udz:"<<tx.lz.list[i].cipher<<", "<<tx.lz.list[i].code<<endl;
                       }
                   }
                   tx_buffer.enqueue(tx);
               }

           }
           else if(pkg.msgtype()==RESORT_TX)
           {
               Tx tx;
               //add lqq
               tx.v_parent=pkg.vparent();
               tx.tx_type=pkg.msgtype();
               tx.v_bef=pkg.vbef();
               tx.path=pkg.path();
               tx.cipher=pkg.cipher();
               tx.mtd=pkg.mtd();
               int lsize=pkg.lcip_size();
               int rsize=pkg.rcip_size();
               for(int i=0;i<lsize;i++)
               {
                   if(pkg.lcip(i).length()>0)
                   {
                       tx.lz.list.push_back(Node(pkg.lcip(i),pkg.lenc(i)));
                       //cout<<"tx left udz:"<<tx.lz.list[i].cipher<<", "<<tx.lz.list[i].code<<endl;
                   }
               }
               for(int i=0;i<rsize;i++)
               {
                   if(pkg.rcip(i).length()>0)
                   {
                       tx.rz.list.push_back(Node(pkg.rcip(i),pkg.renc(i)));
                       //cout<<"tx right udz:"<<tx.rz.list[i].cipher<<", "<<tx.rz.list[i].code<<endl;
                   }
               }
               tx_buffer.enqueue(tx);
           }
           else
           {
               cerr<<"wrong message type when rec: "<<pkg.msgtype()<<", n="<<n<<endl;
           }
       }
    }
}

int main(int argc, char *argv[])
{
    vector<int> cip_v;
    for(int i=0;i<TXN;i++)
    {
        cip_v.push_back(i);
    }
    random_shuffle(cip_v.begin(),cip_v.end());
    for(int i=0;i<TXN;i++)
    {
        string data="cipher"+to_string(cip_v[i]);
        enc_req enc;
        enc.id=i;
        enc.cipher=data;
        enc_queue.enqueue(enc);
    }
    root=new Node("cipher-1",-1);
    Node* node=new Node("cipher"+to_string(TXN),M);
    root->right=node;
    node->parent=root;
    //grab the port number
    int port = 8080/*atoi(argv[1])*/;
    //buffer to send and receive messages with

    //setup a socket and connection tools
    sockaddr_in servAddr;
    bzero((char*)&servAddr, sizeof(servAddr));
    servAddr.sin_family = AF_INET;
    servAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servAddr.sin_port = htons(port);

    //open stream oriented socket with internet address
    //also keep track of the socket descriptor
    int serverSd = socket(AF_INET, SOCK_STREAM, 0);
    if(serverSd < 0)
    {
        cerr << "Error establishing the server socket" << endl;
        exit(0);
    }
    //bind the socket to its local address
    int bindStatus = ::bind(serverSd, (struct sockaddr*) &servAddr,
                          sizeof(servAddr));
    if(bindStatus < 0)
    {
        cerr << "Error binding socket to local address" << endl;
        exit(0);
    }
    cout << "Waiting for a client to connect..." << endl;
    //listen for up to 5 requests at a time
    listen(serverSd, 5);
    //receive a request from client using accept
    //we need a new address to connect with the client
    sockaddr_in newSockAddr;
    socklen_t newSockAddrSize = sizeof(newSockAddr);
    //accept, create a new socket descriptor to
    //handle the new connection with client
    int newSd = accept(serverSd, (sockaddr *)&newSockAddr, &newSockAddrSize);
    if(newSd < 0)
    {
        cerr << "Error accepting request from client!" << endl;
        exit(1);
    }
    cout << "Connected with client!" << endl;
    pthread_t tid1[NUM_ENCODE],tid2[NUM_REC],tid3[EXE_TX];
    struct thread_data td1[NUM_ENCODE],td2[NUM_REC],td3[EXE_TX];
    for(int i=0; i < NUM_ENCODE; i++ ){
        td1[i].thread_id = i;
        td1[i].Sd = newSd;
        int rc = pthread_create(&tid1[i], nullptr,do_encode, (void *)&td1[i]);
        pthread_detach(tid1[i]);
        if (rc){
            cout << "Error:unable to create thread," << rc << endl;
            exit(-1);
        }
    }
    for(int i=0; i < NUM_REC; i++ ){
            td2[i].thread_id = i;
            td2[i].Sd = newSd;
            int rc = pthread_create(&tid2[i], nullptr,do_rec, (void *)&td2[i]);
            pthread_detach(tid2[i]);
            if (rc){
                cout << "Error:unable to create thread," << rc << endl;
                exit(-1);
            }
        }
    for(int i=0; i < EXE_TX; i++ ){
        td3[i].thread_id = i;
        int rc = pthread_create(&tid3[i], nullptr,write_tree, (void *)&td3[i]);
        pthread_detach(tid3[i]);
        if (rc){
            cout << "Error:unable to create thread," << rc << endl;
            exit(-1);
        }
    }
    pthread_t tid4;
    struct thread_data td4;
    td4.Sd=newSd;
    int rc = pthread_create(&tid4, nullptr,do_query, (void *)&td4);
    pthread_detach(tid4);
    if (rc){
        cout << "Error:unable to create thread," << rc << endl;
        exit(-1);
    }
    //HZC
//    for(int i=0; i < 1; i++ ){
//        td4[i].thread_id = i;
//        int rc = pthread_create(&tid4[i], nullptr,print_tps, (void *)&td4[i]);
//        pthread_detach(tid4[i]);
//        if (rc){
//            cout << "Error:unable to create thread," << rc << endl;
//            exit(-1);
//        }
//    }
    while(1){
        print_tps();
    }
    return 0;
}

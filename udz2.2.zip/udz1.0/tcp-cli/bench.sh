#!/bin/bash

for i in {1..24}
do
{
nohup ./client &
}
done

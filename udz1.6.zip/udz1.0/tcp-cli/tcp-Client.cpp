#include <iostream>
#include <string>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include <mutex>
#include <time.h>
#include<algorithm>
#include <queue>
#include "tcp-Client.h"
using namespace std;
//for encrypt and decrypt
map<string,int> text;//cipher-plain
//cache
map<int,int> cache;//plain-encode
std::mutex mtx_cmp;
std::queue<myPkg> cmp_buffer;
//EventBase eventbase;
int cmp_cli(string ciphertxt,string cipherx)
{
    if(text[cipherx]<-1 ||text[cipherx]>TXN)
        return ERR;
    return text[ciphertxt]-text[cipherx];
}
bool sortFunCip(const string &p1, const string &p2)
{
    string s1=p1;
    string s2=p2;
//    int c1=atoi(s1.substr(6).c_str());
//    int c2=atoi(s2.substr(6).c_str());
    int64_t c1=text[s1];
    int64_t c2=text[s2];
    return text[s1] < text[s2];//升序排列
}
int encode_one(string cipherx,vector<string>& list,vector<int64_t>& code)
{
    int64_t y1=0,y2=0,y=0;
//    int left=0,right=list.size()-1;
    int mid=0,i=0;
//    while(left<=right)
//    {
//        mid=(left+right)/2;
//        int cmprst=cmp_cli(list[mid], cipherx);
//        if(cmprst==0)
//        {
//            cout<<"impossible!!"<<endl;
//            return 0;
//        }
//        else if(cmprst<0)
//        {
//            left=mid+1;
//        }
//        else
//        {
//            right=mid-1;
//        }
//    }
//    int lastrst=cmp_cli(list[mid], cipherx);
//    if(lastrst>0)
//    {
//        i=mid-1;
//        y1=code[mid-1];
//        y2=code[mid];
//        //Print();
//        //cout<<"list["<<mid<<"]="<<list[mid].code<<" ,cipher="<<cipherx<<",pos="<<i<<","<<i+1<<endl;
//    }
//    else if(lastrst<0)
//    {
//        i=mid;
//        y1=code[mid];
//        y2=code[mid+1];
//        //cout<<"list["<<mid<<"]="<<list[mid].code<<" ,cipher="<<cipherx<<",pos="<<i<<","<<i+1<<endl;
//    }
//    else
//        cerr<<"error!!!"<<endl;
    cout<<"------print-----"<<endl;
    cout<<"cipher:"<<cipherx<<endl;
    for(int k=0;k<list.size();k++)
        cout<<"list["<<k<<"]="<<list[k]<<endl;
    cout<<"------end-----"<<endl;
    for(i=0;i<list.size()-1;i++)
    {
        int cmp_rst1=cmp_cli(cipherx,list[i]);
        int cmp_rst2=cmp_cli(cipherx,list[i+1]);
        if(cmp_rst1>=0 && cmp_rst2<0)
        {
            if(cmp_rst1==0)
                cout<<"impossible!!"<<endl;
            y1=code[i];
            y2=code[i+1];
            break;
        }
    }
    if(y2-y1==1)
    {
        cout<<"-----abort "<<cipherx<<endl;
        return 0;
    }
    double a=(double)y1;
    double b=(double)y2;
    y=y1+ceil((double)(b-a)/2);
    cout<<"-----add "<<cipherx<<","<<y<<","<<y1<<","<<y2<<endl;
    list.insert(list.begin()+i+1, cipherx);
    code.insert(code.begin()+i+1, y);
    return y;
}
